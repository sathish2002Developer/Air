declare module 'aos';

