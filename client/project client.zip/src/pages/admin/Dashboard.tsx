import { useState } from 'react';
import { useAdminAuth } from '../../contexts/AdminContext';

interface AdminData {
  products: any[];
  users: any[];
  orders: any[];
  analytics: any;
  settings: any;
  aboutHero: {
    title: string;
    subtitle?: string;
    description?: string;
    backgroundImage: string;
    isActive?: boolean;
  };
  aboutJourneyImage: string;
  visionMission: any;
  heroSlides: any[];
  offerings: any[];
  statistics: any[];
  regulatoryApprovals: any[];
  aboutSections: any[];
  leadership: any[];
  values: any[];
  journey: any[];
  capabilitiesFacilities: any[];
  capabilitiesHero: any;
}

export default function AdminDashboard() {
  const { user, data, logout, addItem, updateItem, deleteItem, updateData } = useAdminAuth();
  const [activeTab, setActiveTab] = useState('home-page');
  const [activeHomeSection, setActiveHomeSection] = useState('hero-slides');
  const [activeAboutSection, setActiveAboutSection] = useState('about-sections');
  const [activeCapabilitiesSection, setActiveCapabilitiesSection] = useState('cap-hero');
  const [activeSustainabilitySection, setActiveSustainabilitySection] = useState<'hero' | 'sdg' | 'policies' | 'vision' | 'innovation' | 'social' | 'footer'>('hero');
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('add');
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Sustainability local state and helpers
  const sustainability: any = (data as any).sustainability || { hero: { title: '', description: '', backgroundImage: '' }, sdgCards: [], policies: [] };
  const [sustHeroTitle, setSustHeroTitle] = useState<string>(sustainability.hero?.title || '');
  const [sustHeroDescription, setSustHeroDescription] = useState<string>(sustainability.hero?.description || '');
  const [sustHeroBg, setSustHeroBg] = useState<string>(sustainability.hero?.backgroundImage || '');

  // Innovation & Transformation helpers
  const it = sustainability.innovationAndTransformation || { sectionTitle: '', sectionDescription: '', isActive: true, digitalSolutions: [], researchInnovation: [] };
  const digitalSolutionsSorted: any[] = (it.digitalSolutions || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0));
  const researchInnovationSorted: any[] = (it.researchInnovation || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0));
  const setItField = (field: 'sectionTitle'|'sectionDescription'|'isActive', value: any) => {
    (updateData as any)('sustainability', {
      ...sustainability,
      innovationAndTransformation: {
        ...(sustainability.innovationAndTransformation || {}),
        [field]: field === 'isActive' ? !!value : value
      }
    });
  };
  const addDigitalCard = () => {
    const nextOrder = (it.digitalSolutions?.length || 0) + 1;
    const newCard = { id: `ds-${Date.now()}`, cardTitle: 'New Title', cardSubtitle: '', cardDescription: '', isActive: true, order: nextOrder };
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, digitalSolutions: [ ...(it.digitalSolutions || []), newCard ] } });
  };
  const updateDigitalField = (id: string, field: 'cardTitle'|'cardSubtitle'|'cardDescription'|'order'|'isActive', value: any) => {
    const updated = (it.digitalSolutions || []).map((c: any) => c.id === id ? { ...c, [field]: field === 'order' ? Number(value)||0 : field === 'isActive' ? !!value : value } : c);
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, digitalSolutions: updated } });
  };
  const deleteDigitalCard = (id: string) => {
    const updated = (it.digitalSolutions || []).filter((c: any) => c.id !== id);
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, digitalSolutions: updated } });
  };
  const addResearchCard = () => {
    const nextOrder = (it.researchInnovation?.length || 0) + 1;
    const newCard = { id: `ri-${Date.now()}`, cardTitle: 'New Title', cardSubtitle: '', cardDescription: '', isActive: true, order: nextOrder };
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, researchInnovation: [ ...(it.researchInnovation || []), newCard ] } });
  };
  const updateResearchField = (id: string, field: 'cardTitle'|'cardSubtitle'|'cardDescription'|'order'|'isActive', value: any) => {
    const updated = (it.researchInnovation || []).map((c: any) => c.id === id ? { ...c, [field]: field === 'order' ? Number(value)||0 : field === 'isActive' ? !!value : value } : c);
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, researchInnovation: updated } });
  };
  const deleteResearchCard = (id: string) => {
    const updated = (it.researchInnovation || []).filter((c: any) => c.id !== id);
    (updateData as any)('sustainability', { ...sustainability, innovationAndTransformation: { ...it, researchInnovation: updated } });
  };

  const saveSustainabilityHero = () => {
    (updateData as any)('sustainability', {
      ...sustainability,
      hero: {
        ...(sustainability.hero || {}),
        title: sustHeroTitle,
        description: sustHeroDescription,
        backgroundImage: sustHeroBg,
        isActive: true
      }
    });
  };

  const sdgCardsSorted: any[] = (sustainability.sdgCards || []).slice().sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
  const addSdgCard = () => {
    openSdgModal('add');
  };
  const updateSdgField = (id: string, field: 'number'|'title'|'contribution'|'icon'|'color'|'order'|'isActive', value: any) => {
    const updated = (sustainability.sdgCards || []).map((c: any) => c.id === id ? { ...c, [field]: (field === 'number' || field === 'order') ? Number(value) || 0 : value } : c);
    (updateData as any)('sustainability', { ...sustainability, sdgCards: updated });
  };
  const deleteSdgCard = (id: string) => {
    const updated = (sustainability.sdgCards || []).filter((c: any) => c.id !== id);
    (updateData as any)('sustainability', { ...sustainability, sdgCards: updated });
  };

  // SDG Modal (add/edit)
  const [sdgModalOpen, setSdgModalOpen] = useState(false);
  const [sdgModalMode, setSdgModalMode] = useState<'add'|'edit'>('add');
  const [sdgEditingId, setSdgEditingId] = useState<string|undefined>(undefined);
  const [sdgForm, setSdgForm] = useState<any>({ number: 3, title: '', contribution: '', icon: 'ri-heart-pulse-line', color: '#2879b6', order: (sustainability.sdgCards?.length||0)+1, isActive: true });
  const openSdgModal = (mode: 'add'|'edit', card?: any) => {
    setSdgModalMode(mode);
    if (mode === 'edit' && card) {
      setSdgEditingId(card.id);
      setSdgForm({ number: card.number, title: card.title, contribution: card.contribution, icon: card.icon, color: card.color, order: card.order, isActive: !!card.isActive });
    } else {
      setSdgEditingId(undefined);
      setSdgForm({ number: 3, title: 'New SDG', contribution: '', icon: 'ri-heart-pulse-line', color: '#2879b6', order: (sustainability.sdgCards?.length||0)+1, isActive: true });
    }
    setSdgModalOpen(true);
  };
  const closeSdgModal = () => setSdgModalOpen(false);
  const saveSdgModal = () => {
    if (sdgModalMode === 'add') {
      const newCard = { id: `sdg-${Date.now()}`, ...sdgForm, number: Number(sdgForm.number)||0, order: Number(sdgForm.order)||0 };
      (updateData as any)('sustainability', { ...sustainability, sdgCards: [ ...(sustainability.sdgCards || []), newCard ] });
    } else if (sdgModalMode === 'edit' && sdgEditingId) {
      const updated = (sustainability.sdgCards || []).map((c: any) => c.id === sdgEditingId ? { ...c, ...sdgForm, number: Number(sdgForm.number)||0, order: Number(sdgForm.order)||0 } : c);
      (updateData as any)('sustainability', { ...sustainability, sdgCards: updated });
    }
    setSdgModalOpen(false);
  };

  const addPolicy = () => {
    const nextOrder = (sustainability.policies?.length || 0) + 1;
    const newPolicy = { id: `pol-${Date.now()}`, title: 'New Policy', description: '', icon: 'ri-shield-check-line', color: '#2879b6', isActive: true, order: nextOrder };
    (updateData as any)('sustainability', { ...sustainability, policies: [ ...(sustainability.policies || []), newPolicy ] });
  };
  const updatePolicyField = (id: string, field: 'title'|'description'|'icon'|'color'|'order'|'isActive', value: any) => {
    const updated = (sustainability.policies || []).map((p: any) => p.id === id ? { ...p, [field]: field === 'order' ? Number(value) || 0 : value } : p);
    (updateData as any)('sustainability', { ...sustainability, policies: updated });
  };
  const deletePolicy = (id: string) => {
    const updated = (sustainability.policies || []).filter((p: any) => p.id !== id);
    (updateData as any)('sustainability', { ...sustainability, policies: updated });
  };

  // Vision & Mission (sustainability)
  const vm = sustainability.visionMission || { visionDescription: '', missionPoints: [] };
  const [vmVisionDesc, setVmVisionDesc] = useState<string>(vm.visionDescription || '');
  const missionPointsSorted: any[] = (vm.missionPoints || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0));
  const saveVisionDesc = () => {
    (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionDescription: vmVisionDesc, missionPoints: missionPointsSorted } });
  };
  const [mpModalOpen, setMpModalOpen] = useState(false);
  const [mpMode, setMpMode] = useState<'add'|'edit'>('add');
  const [mpEditingId, setMpEditingId] = useState<string|undefined>();
  const [mpForm, setMpForm] = useState<any>({ text: '', order: (missionPointsSorted.length||0)+1, isActive: true });
  const openMpModal = (mode: 'add'|'edit', point?: any) => {
    setMpMode(mode);
    if (mode === 'edit' && point) {
      setMpEditingId(point.id);
      setMpForm({ text: point.text, order: point.order, isActive: !!point.isActive });
    } else {
      setMpEditingId(undefined);
      setMpForm({ text: '', order: (missionPointsSorted.length||0)+1, isActive: true });
    }
    setMpModalOpen(true);
  };
  const closeMpModal = () => setMpModalOpen(false);
  const saveMpModal = () => {
    const existing = missionPointsSorted;
    if (mpMode === 'add') {
      const newPoint = { id: `mp-${Date.now()}`, text: mpForm.text, order: Number(mpForm.order)||0, isActive: !!mpForm.isActive };
      const updated = [...existing, newPoint];
      (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionDescription: vmVisionDesc, missionPoints: updated } });
    } else if (mpMode === 'edit' && mpEditingId) {
      const updated = existing.map((p: any) => p.id === mpEditingId ? { ...p, text: mpForm.text, order: Number(mpForm.order)||0, isActive: !!mpForm.isActive } : p);
      (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionDescription: vmVisionDesc, missionPoints: updated } });
    }
    setMpModalOpen(false);
  };
  const deleteMissionPoint = (id: string) => {
    const updated = missionPointsSorted.filter((p: any) => p.id !== id);
    (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionDescription: vmVisionDesc, missionPoints: updated } });
  };

  // Map brand color keys to hex (fallback to given value if already hex)
  const getColorValue = (color: string) => {
    const colorMap = {
      'refex-blue': '#2879b6',
      'refex-green': '#7dc244',
      'refex-orange': '#ee6a31'
    } as const;
    return (colorMap as any)[color] || color || '#2879b6';
  };

  const handleLogout = () => {
    logout();
  };

  const handleAdd = () => {
    setModalType('add');
    setEditingItem(null);
    setFormData({
      achievements: [] // Initialize achievements as empty array
    });
    setShowModal(true);
  };

  const handleEdit = (item: any) => {
    setModalType('edit');
    setEditingItem(item);
    // Ensure achievements is always an array
    const formData = {
      ...item,
      achievements: Array.isArray(item.achievements) ? item.achievements : (item.achievements ? [item.achievements] : [])
    };
    setFormData(formData);
    setShowModal(true);
  };

  const handleDelete = (item: any) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      let sectionKey: keyof AdminData;
      
      if (activeTab === 'home-page') {
        const sectionMap: { [key: string]: keyof AdminData } = {
          'hero-slides': 'heroSlides',
          'offerings': 'offerings',
          'statistics': 'statistics',
          'regulatory': 'regulatoryApprovals'
        };
        sectionKey = sectionMap[activeHomeSection] as keyof AdminData;
      } else if (activeTab === 'about-page') {
        const sectionMap: { [key: string]: keyof AdminData } = {
          'about-hero': 'aboutHero',
          'about-journey-image': 'aboutJourneyImage',
          'vision-mission': 'visionMission',
          'about-sections': 'aboutSections',
          'advisory-board': 'leadership',
          'technical-leadership': 'leadership',
          'management-team': 'leadership',
          'values': 'values',
          'journey': 'journey'
        };
        sectionKey = sectionMap[activeAboutSection] as keyof AdminData;
        if (sectionKey === 'aboutHero' || sectionKey === 'visionMission' || sectionKey === 'aboutJourneyImage') {
          // single object; nothing to delete
          return;
        }
      } else if (activeTab === 'capabilities') {
        deleteItem('capabilitiesFacilities' as any, item.id);
        return;
      } else {
        return;
      }
      
      deleteItem(sectionKey, item.id);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let sectionKey: keyof AdminData;
    
    if (activeTab === 'home-page') {
      const sectionMap: { [key: string]: keyof AdminData } = {
        'hero-slides': 'heroSlides',
        'offerings': 'offerings',
        'statistics': 'statistics',
        'regulatory': 'regulatoryApprovals'
      };
      sectionKey = sectionMap[activeHomeSection] as keyof AdminData;
    } else if (activeTab === 'about-page') {
      const sectionMap: { [key: string]: keyof AdminData } = {
        'about-hero': 'aboutHero',
        'about-journey-image': 'aboutJourneyImage',
        'vision-mission': 'visionMission',
        'about-sections': 'aboutSections',
        'advisory-board': 'leadership',
        'technical-leadership': 'leadership',
        'management-team': 'leadership',
        'values': 'values',
        'journey': 'journey'
      };
      sectionKey = sectionMap[activeAboutSection] as keyof AdminData;
    } else if (activeTab === 'capabilities') {
      if (editingItem === 'capabilities-hero') {
        // Update all hero fields
        const next = {
          ...(data as any).capabilitiesHero,
          title: formData.title || '',
          subtitle: formData.subtitle || '',
          description: formData.description || '',
          subDescription: formData.subDescription || '',
          backgroundImage: formData.backgroundImage || '',
          isActive: formData.isActive ?? true
        };
        updateData('capabilitiesHero' as any, next);
        setShowModal(false);
        setFormData({});
        setEditingItem(null);
        return;
      }

    } else if (activeTab === 'contact-page') {
      if (editingItem === 'contact-hero') {
        // Update all hero fields
        const next = {
          ...(data as any).contactHero,
          title: formData.title || '',
          subtitle: formData.subtitle || '',
          description: formData.description || '',
          backgroundImage: formData.backgroundImage || '',
          isActive: formData.isActive ?? true
        };
        updateData('contactHero' as any, next);
        setEditingItem(null);
        setFormData({});
        return;
      }
      if (editingItem === 'contact-get-in-touch') {
        // Update all get in touch fields
        const next = {
          ...(data as any).contactGetInTouch,
          title: formData.title || '',
          description: formData.description || '',
          location: {
            title: formData.locationTitle || '',
            address: formData.locationAddress || '',
            icon: formData.locationIcon || '',
            color: formData.locationColor || ''
          },
          phone: {
            title: formData.phoneTitle || '',
            number: formData.phoneNumber || '',
            hours: formData.phoneHours || '',
            icon: formData.phoneIcon || '',
            color: formData.phoneColor || ''
          },
          email: {
            title: formData.emailTitle || '',
            address: formData.emailAddress || '',
            responseTime: formData.emailResponseTime || '',
            icon: formData.emailIcon || '',
            color: formData.emailColor || ''
          },
          businessHours: {
            title: formData.businessHoursTitle || '',
            mondayFriday: formData.businessHoursMondayFriday || '',
            saturday: formData.businessHoursSaturday || '',
            sunday: formData.businessHoursSunday || ''
          },
          isActive: formData.isActive ?? true
        };
        updateData('contactGetInTouch' as any, next);
        setEditingItem(null);
        setFormData({});
        return;
      }
      if (editingItem === 'contact-user') {
        if (modalType === 'add') {
          const newUser = {
            id: Date.now().toString(),
            name: formData.name || '',
            email: formData.email || '',
            phone: formData.phone || '',
            department: formData.department || '',
            position: formData.position || '',
            avatar: formData.avatar || '',
            isActive: formData.isActive ?? true,
            order: formData.order || 0
          };
          const updatedUsers = [...((data as any).contactUsers || []), newUser];
          updateData('contactUsers' as any, updatedUsers);
        } else {
          const updatedUsers = ((data as any).contactUsers || []).map((user: any) =>
            user.id === formData.id
              ? {
                  ...user,
                  name: formData.name || '',
                  email: formData.email || '',
                  phone: formData.phone || '',
                  department: formData.department || '',
                  position: formData.position || '',
                  avatar: formData.avatar || '',
                  isActive: formData.isActive ?? true,
                  order: formData.order || 0
                }
              : user
          );
          updateData('contactUsers' as any, updatedUsers);
        }
        setShowModal(false);
        setFormData({});
        setEditingItem(null);
        return;
      }
      if (editingItem === 'home-global-impact') {
        // Update home global impact section
        const next = {
          ...(data as any).homeGlobalImpact,
          title: formData.title || '',
          description: formData.description || '',
          isActive: formData.isActive ?? true
        };
        updateData('homeGlobalImpact' as any, next);
        setShowModal(false);
        setFormData({});
        setEditingItem(null);
        return;
      }
      if (editingItem === 'capabilities-research') {
        updateData('capabilitiesResearch' as any, formData);
        setShowModal(false);
        setFormData({});
        setEditingItem(null);
        return;
      }
      sectionKey = 'capabilitiesFacilities';
    } else {
      return;
    }

    if (sectionKey === 'aboutHero') {
      // direct update object
      updateData('aboutHero', formData);
    } else if (sectionKey === 'aboutJourneyImage') {
      updateData('aboutJourneyImage', formData.image || '');
    } else if (sectionKey === 'visionMission') {
      const normalized = { ...formData } as any;
      if (typeof normalized.missionPointsRaw === 'string') {
        try {
          normalized.missionPoints = JSON.parse(normalized.missionPointsRaw);
        } catch {}
        delete normalized.missionPointsRaw;
      }
      updateData('visionMission', normalized);
    } else {
      // Normalize Advisory Board category when editing/adding through Advisory tab
      if (sectionKey === 'leadership' && activeAboutSection === 'advisory-board') {
        formData.category = 'Advisory Board';
      }
      // Normalize Technical Leadership Team category when editing/adding through Technical Leadership tab
      if (sectionKey === 'leadership' && activeAboutSection === 'technical-leadership') {
        formData.category = 'Technical Leadership Team';
      }
      // Normalize Management Team category when editing/adding through Management Team tab
      if (sectionKey === 'leadership' && activeAboutSection === 'management-team') {
        formData.category = 'Management Team';
      }
      if (sectionKey === 'capabilitiesFacilities') {
        if (typeof formData.capabilitiesRaw === 'string') {
          formData.capabilities = (formData.capabilitiesRaw as string).split('\n').map((s: string) => s.trim()).filter(Boolean);
          delete formData.capabilitiesRaw;
        }
        if (typeof formData.approvalsRaw === 'string') {
          formData.approvals = (formData.approvalsRaw as string).split('\n').map((s: string) => s.trim()).filter(Boolean);
          delete formData.approvalsRaw;
        }
      }
      if (modalType === 'add') {
        if (typeof formData.achievementsRaw === 'string') {
          formData.achievements = (formData.achievementsRaw as string).split('\n').map(s => s.trim()).filter(Boolean);
          delete formData.achievementsRaw;
        }
        addItem(sectionKey, formData);
      } else {
        if (typeof formData.achievementsRaw === 'string') {
          formData.achievements = (formData.achievementsRaw as string).split('\n').map(s => s.trim()).filter(Boolean);
          delete formData.achievementsRaw;
        }
        updateItem(sectionKey, (editingItem as any)?.id || '', formData);
      }
    }
    
    setShowModal(false);
    setFormData({});
    setEditingItem(null);
    setImagePreview(null);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev: any) => ({
      ...prev,
      [field]: value
    }));
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check if file is an image
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
      }
      
      // Check file size (max 1MB to prevent localStorage quota issues)
      if (file.size > 1 * 1024 * 1024) {
        alert('Image size should be less than 1MB to prevent storage issues. Please use external image URLs for larger images.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setImagePreview(result);
        setFormData((prev: any) => ({
          ...prev,
          image: result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const StatCard = ({ title, value, icon, color, change }: any) => (
    <div className="bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: color }}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {change && (
            <p className="text-sm text-green-600 flex items-center mt-1">
              <i className="ri-arrow-up-line mr-1"></i>
              {change}
            </p>
          )}
        </div>
        <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${color}20` }}>
          <i className={`${icon} text-xl`} style={{ color }}></i>
        </div>
      </div>
    </div>
  );

  const DataTable = ({ title, data, columns }: any) => (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {columns.map((col: any, index: number) => (
                <th key={index} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {col.header}
                </th>
              ))}
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((item: any, index: number) => (
              <tr key={item.id || index} className="hover:bg-gray-50">
                {columns.map((col: any, colIndex: number) => (
                  <td key={colIndex} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {col.render ? col.render(item[col.key]) : item[col.key]}
                  </td>
                ))}
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(item)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      <i className="ri-edit-line"></i>
                    </button>
                    <button
                      onClick={() => handleDelete(item)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <i className="ri-delete-bin-line"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-shield-user-line text-white"></i>
              </div>
              <h1 className="text-xl font-semibold text-gray-800">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user?.username}</span>
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                <i className="ri-logout-box-line mr-2"></i>
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-8 overflow-x-auto">
            {[
              { id: 'home-page', label: 'Home Page', icon: 'ri-home-line' },
              { id: 'about-page', label: 'About Page', icon: 'ri-information-line' },
              { id: 'capabilities', label: 'Capabilities', icon: 'ri-cpu-line' },
              { id: 'contact-page', label: 'Contact Page', icon: 'ri-phone-line' },
              { id: 'products', label: 'Products', icon: 'ri-medicine-bottle-line' },
              { id: 'sustainability', label: 'Sustainability', icon: 'ri-leaf-line' },
              { id: 'settings', label: 'Settings', icon: 'ri-settings-line' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Overview Tab removed */}

        {/* Home Page Tab - Unified Management */}
        {activeTab === 'home-page' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Home Page Management</h2>
            </div>

            {/* Home Page Sections Navigation */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex space-x-4 overflow-x-auto">
                {[
                  { id: 'hero-slides', label: 'Hero Slides', icon: 'ri-image-line', count: data.heroSlides.length },
                  { id: 'offerings', label: 'What We Offer', icon: 'ri-star-line', count: data.offerings.length },
                  { id: 'statistics', label: 'Global Impact', icon: 'ri-global-line', count: data.statistics.length },
                  { id: 'regulatory', label: 'Regulatory', icon: 'ri-shield-check-line', count: data.regulatoryApprovals.length }
                ].map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveHomeSection(section.id)}
                    className={`flex items-center px-4 py-3 rounded-lg transition-colors whitespace-nowrap ${
                      activeHomeSection === section.id
                        ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                        : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <i className={`${section.icon} mr-2`}></i>
                    <span className="font-medium">{section.label}</span>
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                      activeHomeSection === section.id
                        ? 'bg-blue-200 text-blue-800'
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {section.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Hero Slides Section */}
            {activeHomeSection === 'hero-slides' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Hero Slides Management</h3>
                  <button 
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Slide
                  </button>
                </div>
                <DataTable
                  title="Hero Slides"
                  data={data.heroSlides}
                  columns={[
                    { key: 'title', header: 'Title' },
                    { 
                      key: 'image', 
                      header: 'Preview',
                      render: (value: string) => (
                        <img src={value} alt="Slide" className="w-16 h-10 object-cover rounded" />
                      )
                    },
                    { key: 'order', header: 'Order' },
                    { 
                      key: 'isActive', 
                      header: 'Status',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    }
                  ]}
                />
              </div>
            )}
       
         

            {/* Offerings Section */}
            {activeHomeSection === 'offerings' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">What We Offer Management</h3>
                  <button 
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Offering
                  </button>
                </div>
                <DataTable
                  title="Offerings"
                  data={data.offerings}
                  columns={[
                    { key: 'title', header: 'Title' },
                    { key: 'description', header: 'Description' },
                    { key: 'metric', header: 'Metric' },
                    { key: 'unit', header: 'Unit' },
                    { 
                      key: 'color', 
                      header: 'Color',
                      render: (value: string) => (
                        <div className="flex items-center">
                          <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: getColorValue(value) }}></div>
                          <span className="text-xs">{value}</span>
                        </div>
                      )
                    },
                    { key: 'order', header: 'Order' },
                    { 
                      key: 'isActive', 
                      header: 'Status',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    }
                  ]}
                />
              </div>
            )}

            {/* Statistics Section */}
            {activeHomeSection === 'statistics' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Global Impact & Excellence</h3>
                  <div className="flex space-x-3">
                    <button
                      onClick={() => {
                        setModalType('edit');
                        setEditingItem('home-global-impact');
                        const globalImpactData = (data as any).homeGlobalImpact || {};
                        const formDataToSet = {
                          title: globalImpactData.title || '',
                          description: globalImpactData.description || '',
                          isActive: globalImpactData.isActive ?? true
                        };
                        setFormData(formDataToSet);
                        setShowModal(true);
                      }}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                    >
                      <i className="ri-edit-line mr-2"></i>
                      Edit Section
                    </button>
                    <button 
                      onClick={() => handleAdd()}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                    >
                      <i className="ri-add-line mr-2"></i>
                      Add Statistic
                    </button>
                  </div>
                </div>

                {/* Global Impact Preview */}
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Preview</h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="text-center mb-8">
                      <h4 className="text-2xl md:text-3xl font-bold mb-4 text-gray-800 font-montserrat">
                        {(data as any).homeGlobalImpact?.title || 'Global Impact & Excellence'}
                      </h4>
                      <p className="text-base text-gray-600 max-w-3xl mx-auto leading-relaxed font-montserrat">
                        {(data as any).homeGlobalImpact?.description || 'Trusted by healthcare professionals worldwide with proven expertise and unwavering commitment to quality'}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {(data.statistics || [])
                        .filter((stat: any) => stat.isActive)
                        .sort((a: any, b: any) => a.order - b.order)
                        .map((stat: any, index: number) => (
                        <div key={index} className="group bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-700 transform hover:-translate-y-2 hover:rotate-1 cursor-pointer border-l-4" style={{ borderColor: getColorValue(stat.color) }}>
                          {/* Card Image */}
                          <div className="relative h-48 overflow-hidden">
                            <img 
                              src={stat.image || 'https://via.placeholder.com/400x200?text=Image'} 
                              alt={stat.title}
                              className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700"
                              onError={(e) => {
                                e.currentTarget.src = 'https://via.placeholder.com/400x200?text=Image+Not+Available';
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 via-gray-600/20 to-transparent"></div>
                          </div>
                          
                          {/* Card Content */}
                          <div className="p-6">
                            <div className="text-center">
                              <div className="text-3xl font-bold mb-2 group-hover:scale-110 transition-transform duration-300" style={{ color: getColorValue(stat.color), fontFamily: 'Montserrat, sans-serif' }}>
                                {stat.value}
                              </div>
                              <h3 className="text-base font-bold text-gray-800 mb-2 transition-colors duration-300 group-hover:text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                                {stat.title}
                              </h3>
                              <p className="text-gray-600 text-sm leading-relaxed group-hover:text-gray-700 transition-colors duration-300" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                                {stat.description}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <DataTable
                  title="Statistics"
                  data={data.statistics}
                  columns={[
                    { key: 'title', header: 'Title' },
                    { key: 'value', header: 'Value' },
                    { key: 'description', header: 'Description' },
                    { 
                      key: 'image', 
                      header: 'Preview',
                      render: (value: string) => (
                        <img src={value} alt="Stat" className="w-16 h-10 object-cover rounded" />
                      )
                    },
                    { 
                      key: 'color', 
                      header: 'Color',
                      render: (value: string) => (
                        <div className="flex items-center">
                          <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: value }}></div>
                          <span className="text-xs">{value}</span>
                        </div>
                      )
                    },
                    { key: 'order', header: 'Order' },
                    { 
                      key: 'isActive', 
                      header: 'Status',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    }
                  ]}
                />
              </div>
            )}

            {/* Regulatory Section */}
            {activeHomeSection === 'regulatory' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Regulatory Approvals</h3>
                  <button 
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Approval
                  </button>
                </div>
                <DataTable
                  title="Regulatory Approvals"
                  data={data.regulatoryApprovals}
                  columns={[
                    { key: 'title', header: 'Title' },
                    { key: 'description', header: 'Description' },
                    { 
                      key: 'image', 
                      header: 'Logo',
                      render: (value: string) => (
                        <img src={value} alt="Logo" className="w-16 h-10 object-contain rounded" />
                      )
                    },
                    {
                      key: 'link',
                      header: 'Link',
                      render: (value: string) => (
                        value ? <a href={value} target="_blank" rel="noreferrer" className="text-blue-600 underline">Open</a> : <span className="text-gray-400">—</span>
                      )
                    },
                    { 
                      key: 'color', 
                      header: 'Color',
                      render: (value: string) => (
                        <div className="flex items-center">
                          <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: value }}></div>
                          <span className="text-xs">{value}</span>
                        </div>
                      )
                    },
                    { key: 'order', header: 'Order' },
                    { 
                      key: 'isActive', 
                      header: 'Status',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    }
                  ]}
                />
              </div>
            )}

          </div>
        )}

        {/* About Page Tab */}
        {activeTab === 'about-page' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">About Page Management</h2>
            </div>

            {/* About Page Sections Navigation */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex space-x-4 overflow-x-auto">
                {[ 
                  { id: 'about-hero', label: 'About Hero', icon: 'ri-layout-top-line', count: 1 },
                  { id: 'about-journey-image', label: 'Journey Image', icon: 'ri-image-line', count: 1 },
                  { id: 'vision-mission', label: 'Vision & Mission', icon: 'ri-eye-line', count: 1 },
                
                  { id: 'advisory-board', label: 'Advisory Board', icon: 'ri-team-line', count: (data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'advisory board').length },
                  { id: 'technical-leadership', label: 'Technical Leadership Team', icon: 'ri-flask-line', count: (data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'technical leadership team').length },
                  { id: 'management-team', label: 'Management Team', icon: 'ri-user-star-line', count: (data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'management team').length },
                
                ].map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveAboutSection(section.id)}
                    className={`flex items-center px-4 py-3 rounded-lg transition-colors whitespace-nowrap ${
                      activeAboutSection === section.id
                        ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                        : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <i className={`${section.icon} mr-2`}></i>
                    <span className="font-medium">{section.label}</span>
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                      activeAboutSection === section.id
                        ? 'bg-blue-200 text-blue-800'
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {section.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Journey Image Content */}
            {activeAboutSection === 'about-journey-image' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Journey Image</h3>
                  <button
                    onClick={() => {
                      setModalType('edit');
                      setEditingItem('about-journey-image');
                      setFormData({ image: data.aboutJourneyImage || '' });
                      setShowModal(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-edit-line mr-2"></i>
                    Edit Image
                  </button>
                </div>
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6">
                    <p className="text-sm text-gray-500 mb-2">Preview</p>
                    <img src={data.aboutJourneyImage} alt="Journey" className="w-full h-56 object-contain rounded bg-gray-50" />
                  </div>
                </div>
              </div>
            )}

            {/* Vision & Mission Content */}
            {activeAboutSection === 'vision-mission' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Vision & Mission</h3>
                  <button
                    onClick={() => {
                      setModalType('edit');
                      setEditingItem('vision-mission');
                      setFormData({
                        ...((data as any).visionMission || {}),
                        missionPointsRaw: JSON.stringify(((data as any).visionMission?.missionPoints || []), null, 2)
                      });
                      setShowModal(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-edit-line mr-2"></i>
                    Edit
                  </button>
                </div>
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Vision Title</p>
                      <p className="text-gray-900 font-semibold">{(data as any).visionMission?.visionTitle || 'Our Vision'}</p>
                      <p className="text-sm text-gray-500 mt-4 mb-1">Vision Description</p>
                      <p className="text-gray-900">{(data as any).visionMission?.visionDescription || ''}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-2">Vision Image</p>
                      <img src={(data as any).visionMission?.visionImage} alt="Vision" className="w-full h-40 object-cover rounded" />
                    </div>
                  </div>
                  <div className="px-6 pb-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Mission Title</p>
                      <p className="text-gray-900 font-semibold">{(data as any).visionMission?.missionTitle || 'Our Mission'}</p>
                      <p className="text-sm text-gray-500 mt-4 mb-1">Mission Points</p>
                      <ul className="list-disc list-inside text-gray-900 space-y-1">
                        {(((data as any).visionMission?.missionPoints) || []).map((p: any, idx: number) => (
                          <li key={idx}><span className="font-medium">{p.title}:</span> {p.description}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-2">Mission Image</p>
                      <img src={(data as any).visionMission?.missionImage} alt="Mission" className="w-full h-40 object-cover rounded" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* About Hero Content */}
            {activeAboutSection === 'about-hero' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">About Hero</h3>
                  <button
                    onClick={() => {
                      setModalType('edit');
                      setEditingItem('about-hero');
                      setFormData(data.aboutHero || {});
                      setShowModal(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-edit-line mr-2"></i>
                    Edit Hero
                  </button>
                </div>
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Title</p>
                      <p className="text-gray-900 font-semibold">{data.aboutHero?.title || 'About RLS'}</p>
                      {data.aboutHero?.subtitle && (
                        <>
                          <p className="text-sm text-gray-500 mt-4 mb-1">Subtitle</p>
                          <p className="text-gray-900">{data.aboutHero.subtitle}</p>
                        </>
                      )}
                      {data.aboutHero?.description && (
                        <>
                          <p className="text-sm text-gray-500 mt-4 mb-1">Description</p>
                          <p className="text-gray-900">{data.aboutHero.description}</p>
                        </>
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-2">Background Preview</p>
                      <img src={data.aboutHero?.backgroundImage} alt="About Hero" className="w-full h-40 object-cover rounded" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* About Sections Content */}
            {activeAboutSection === 'about-sections' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">About Sections Management</h3>
                  <button
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Section
                  </button>
                </div>
                <DataTable
                  title="About Sections"
                  data={data.aboutSections || []}
                  columns={[
                    { key: 'title', header: 'TITLE' },
                    { key: 'content', header: 'CONTENT' },
                    { 
                      key: 'icon', 
                      header: 'ICON',
                      render: (value: string) => <i className={`${value} text-lg`}></i>
                    }
                  ]}
                />
              </div>
            )}

            {/* Leadership Content - Removed per request */}

            {/* Advisory Board Content */}
            {activeAboutSection === 'advisory-board' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Advisory Board Management</h3>
                  <button
                    onClick={() => {
                      setEditingItem(null);
                      setFormData({
                        name: '',
                        position: '',
                        description: '',
                        achievements: [],
                        experience: '',
                        education: '',
                        image: '',
                        color: 'refex-blue',
                        category: 'Advisory Board',
                        isActive: true,
                        order: (data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'advisory board').length + 1
                      });
                      setImagePreview(null);
                      setShowModal(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Advisor
                  </button>
                </div>

                {/* Advisory Board Preview */}
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Advisory Board Preview</h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex flex-wrap justify-center gap-8 items-center">
                      {(data.leadership || [])
                        .filter((leader: any) => (leader.category || '').toLowerCase() === 'advisory board' && leader.isActive)
                        .sort((a: any, b: any) => a.order - (b.order || 0))
                        .map((leader: any, index: number) => {
                          const getColorClasses = (color: string) => {
                            const colorMap = {
                              'refex-blue': { border: 'border-[#2879b6]', text: 'text-[#2879b6]' },
                              'refex-green': { border: 'border-[#7dc244]', text: 'text-[#7dc244]' },
                              'refex-orange': { border: 'border-[#ee6a31]', text: 'text-[#ee6a31]' }
                            };
                            return colorMap[color as keyof typeof colorMap] || colorMap['refex-blue'];
                          };
                          const colors = getColorClasses(leader.color || 'refex-blue');
                          return (
                            <div
                              key={index}
                              className="group relative cursor-pointer transform transition-all duration-500 hover:scale-110 hover:-translate-y-4 flex flex-col items-center"
                            >
                              <div
                                className={`w-40 h-40 rounded-full overflow-hidden shadow-2xl border-4 border-white ${colors.border} group-hover:shadow-3xl transition-all duration-500`}
                              >
                                <img
                                  src={leader.image || 'https://via.placeholder.com/160x160?text=Advisor'}
                                  alt={leader.name}
                                  className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
                                  onError={(e) => {
                                    e.currentTarget.src = 'https://via.placeholder.com/160x160?text=Image+Not+Available';
                                  }}
                                />
                              </div>

                              {/* Always Visible Name and Position */}
                              <div className="mt-4 text-center">
                                <p className="text-sm font-bold text-gray-800 font-montserrat leading-tight">
                                  {leader.name}
                                </p>
                                <p
                                  className={`text-xs ${colors.text} font-semibold font-montserrat mt-1 leading-tight`}
                                >
                                  {leader.position}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                    
                    {((data.leadership || []).filter((leader: any) => (leader.category || '').toLowerCase() === 'advisory board' && leader.isActive).length === 0) && (
                      <div className="text-center py-8">
                        <i className="ri-team-line text-4xl text-gray-300 mb-4"></i>
                        <p className="text-gray-500 font-montserrat">No Advisory Board members added yet</p>
                      </div>
                    )}
                  </div>
                </div>

                <DataTable
                  title="Advisory Board"
                  data={(data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'advisory board')}
                  columns={[
                    { key: 'name', header: 'NAME' },
                    { key: 'position', header: 'POSITION' },
                    {
                      key: 'image',
                      header: 'PHOTO',
                      render: (value: string) => (
                        <img src={value || 'https://via.placeholder.com/150'} alt="Advisor" className="w-12 h-12 rounded-full object-cover border" />
                      )
                    },
                    { key: 'experience', header: 'EXPERIENCE' },
                    { key: 'education', header: 'EDUCATION' },
                    {
                      key: 'isActive',
                      header: 'STATUS',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    },
                    {
                      key: 'actions',
                      header: 'ACTIONS',
                      render: (item: any) => (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingItem(item.id);
                              setFormData({
                                ...item,
                                achievementsRaw: Array.isArray(item.achievements) ? item.achievements.join('\n') : ''
                              });
                              setImagePreview(null);
                              setShowModal(true);
                            }}
                            className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                          >
                            <i className="ri-edit-line"></i>
                          </button>
                          <button
                            onClick={() => deleteItem('leadership', item.id)}
                            className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
                          >
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      )
                    }
                  ]}
                />
              </div>
            )}

            {/* Technical Leadership Team Content */}
            {activeAboutSection === 'technical-leadership' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Technical Leadership Team</h3>
                  <button
                    onClick={() => {
                      setEditingItem(null);
                      setFormData({
                        name: '',
                        position: '',
                        description: '',
                        achievements: [],
                        experience: '',
                        education: '',
                        image: '',
                        color: 'refex-blue',
                        category: 'Technical Leadership Team',
                        isActive: true,
                        order: (data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'technical leadership team').length + 1
                      });
                      setShowModal(true);
                    }}
                    className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Technical Leader
                  </button>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Technical Leadership Team Preview</h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex flex-wrap justify-center gap-8 items-center">
                      {(data.leadership || [])
                        .filter((leader: any) => (leader.category || '').toLowerCase() === 'technical leadership team' && leader.isActive)
                        .sort((a: any, b: any) => a.order - (b.order || 0))
                        .map((leader: any, index: number) => {
                          const getColorClasses = (color: string) => {
                            const colorMap = {
                              'refex-blue': { border: 'border-[#2879b6]', text: 'text-[#2879b6]' },
                              'refex-green': { border: 'border-[#7dc244]', text: 'text-[#7dc244]' },
                              'refex-orange': { border: 'border-[#ee6a31]', text: 'text-[#ee6a31]' }
                            };
                            return colorMap[color as keyof typeof colorMap] || colorMap['refex-blue'];
                          };
                          const colors = getColorClasses(leader.color || 'refex-blue');
                          return (
                            <div
                              key={leader.id}
                              className="group relative cursor-pointer transform transition-all duration-500 hover:scale-110 hover:-translate-y-4 flex flex-col items-center"
                              data-aos="zoom-in"
                              data-aos-duration="800"
                              data-aos-delay={index * 100}
                            >
                              <div
                                className={`w-40 h-40 rounded-full overflow-hidden shadow-2xl border-4 border-white ${colors.border} group-hover:shadow-3xl transition-all duration-500`}
                              >
                                <img
                                  src={leader.image || 'https://via.placeholder.com/150'}
                                  alt={leader.name}
                                  className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
                                />
                              </div>

                              <div className="mt-4 text-center">
                                <p className="text-sm font-bold text-gray-800 font-montserrat leading-tight">
                                  {leader.name}
                                </p>
                                <p
                                  className={`text-xs ${colors.text} font-semibold font-montserrat mt-1 leading-tight`}
                                >
                                  {leader.position}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                    
                    {((data.leadership || []).filter((leader: any) => (leader.category || '').toLowerCase() === 'technical leadership team' && leader.isActive).length === 0) && (
                      <div className="text-center py-8">
                        <i className="ri-flask-line text-4xl text-gray-300 mb-4"></i>
                        <p className="text-gray-500 font-montserrat">No Technical Leadership Team members added yet</p>
                      </div>
                    )}
                  </div>
                </div>

                <DataTable
                  title="Technical Leadership Team"
                  data={(data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'technical leadership team')}
                  columns={[
                    { key: 'name', header: 'NAME' },
                    { key: 'position', header: 'POSITION' },
                    {
                      key: 'image',
                      header: 'IMAGE',
                      render: (item: any) => (
                        <div className="w-12 h-12 rounded-full overflow-hidden">
                          <img
                            src={item.image || 'https://via.placeholder.com/150'}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )
                    },
                    { key: 'experience', header: 'EXPERIENCE' },
                    { key: 'education', header: 'EDUCATION' },
                    {
                      key: 'isActive',
                      header: 'STATUS',
                      render: (item: any) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          item.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {item.isActive ? 'Active' : 'Inactive'}
                        </span>
                      )
                    },
                    {
                      key: 'actions',
                      header: 'ACTIONS',
                      render: (item: any) => (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingItem(item.id);
                              setFormData({
                                ...item,
                                achievementsRaw: Array.isArray(item.achievements) ? item.achievements.join('\n') : ''
                              });
                              setShowModal(true);
                            }}
                            className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                          >
                            <i className="ri-edit-line"></i>
                          </button>
                          <button
                            onClick={() => deleteItem('leadership', item.id)}
                            className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
                          >
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      )
                    }
                  ]}
                />
              </div>
            )}

            {/* Management Team Content */}
            {activeAboutSection === 'management-team' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Management Team</h3>
                  <button
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Member
                  </button>
                </div>

                {/* Management Team Preview */}
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Management Team Preview</h4>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex flex-wrap justify-center gap-8 items-center">
                      {(data.leadership || [])
                        .filter((leader: any) => (leader.category || '').toLowerCase() === 'management team' && leader.isActive)
                        .sort((a: any, b: any) => a.order - (b.order || 0))
                        .map((leader: any, index: number) => {
                          const getColorClasses = (color: string) => {
                            const colorMap = {
                              'refex-blue': { border: 'border-[#2879b6]', text: 'text-[#2879b6]' },
                              'refex-green': { border: 'border-[#7dc244]', text: 'text-[#7dc244]' },
                              'refex-orange': { border: 'border-[#ee6a31]', text: 'text-[#ee6a31]' }
                            };
                            return colorMap[color as keyof typeof colorMap] || colorMap['refex-blue'];
                          };
                          const colors = getColorClasses(leader.color || 'refex-blue');
                          return (
                            <div
                              key={index}
                              className="group relative cursor-pointer transform transition-all duration-500 hover:scale-110 hover:-translate-y-4 flex flex-col items-center"
                            >
                              <div
                                className={`w-40 h-40 rounded-full overflow-hidden shadow-2xl border-4 border-white ${colors.border} group-hover:shadow-3xl transition-all duration-500`}
                              >
                                <img
                                  src={leader.image || 'https://via.placeholder.com/160x160?text=Manager'}
                                  alt={leader.name}
                                  className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
                                  onError={(e) => {
                                    e.currentTarget.src = 'https://via.placeholder.com/160x160?text=Image+Not+Available';
                                  }}
                                />
                              </div>

                              {/* Always Visible Name and Position */}
                              <div className="mt-4 text-center">
                                <p className="text-sm font-bold text-gray-800 font-montserrat leading-tight">
                                  {leader.name}
                                </p>
                                <p
                                  className={`text-xs ${colors.text} font-semibold font-montserrat mt-1 leading-tight`}
                                >
                                  {leader.position}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                    
                    {((data.leadership || []).filter((leader: any) => (leader.category || '').toLowerCase() === 'management team' && leader.isActive).length === 0) && (
                      <div className="text-center py-8">
                        <i className="ri-user-star-line text-4xl text-gray-300 mb-4"></i>
                        <p className="text-gray-500 font-montserrat">No Management Team members added yet</p>
                      </div>
                    )}
                  </div>
                </div>

                <DataTable
                  title="Management Team"
                  data={(data.leadership || []).filter((m: any) => (m.category || '').toLowerCase() === 'management team')}
                  columns={[
                    { key: 'name', header: 'NAME' },
                    { key: 'position', header: 'POSITION' },
                    {
                      key: 'image',
                      header: 'PHOTO',
                      render: (value: string) => (
                        <img src={value} alt="Member" className="w-12 h-12 rounded-full object-cover border" />
                      )
                    },
                    { key: 'order', header: 'ORDER' },
                    {
                      key: 'isActive',
                      header: 'STATUS',
                      render: (value: boolean) => (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          {value ? 'Active' : 'Inactive'}
                        </span>
                      )
                    }
                  ]}
                />
              </div>
            )}

            {/* Values Content */}
            {activeAboutSection === 'values' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Values Management</h3>
                  <button
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Value
                  </button>
                </div>
                <DataTable
                  title="Core Values"
                  data={data.values || []}
                  columns={[
                    { key: 'title', header: 'TITLE' },
                    { key: 'description', header: 'DESCRIPTION' },
                    { 
                      key: 'icon', 
                      header: 'ICON',
                      render: (value: string) => <i className={`${value} text-lg`}></i>
                    }
                  ]}
                />
              </div>
            )}

            {/* Journey Content */}
            {activeAboutSection === 'journey' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Journey Management</h3>
                  <button
                    onClick={() => handleAdd()}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Add Milestone
                  </button>
                </div>
                <DataTable
                  title="Company Journey"
                  data={data.journey || []}
                  columns={[
                    { key: 'title', header: 'TITLE' },
                    { key: 'description', header: 'DESCRIPTION' },
                    { key: 'year', header: 'YEAR' }
                  ]}
                />
              </div>
            )}
          </div>
        )}

        {/* Products Tab */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Products Management</h2>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                <i className="ri-add-line mr-2"></i>
                Add Product
              </button>
            </div>
            <DataTable
              title="Products"
              data={data.products}
              columns={[
                { key: 'name', header: 'Product Name' },
                { key: 'category', header: 'Category' },
                { 
                  key: 'price', 
                  header: 'Price',
                  render: (value: number) => `$${value}`
                },
                { key: 'stock', header: 'Stock' },
                { 
                  key: 'status', 
                  header: 'Status',
                  render: (value: string) => (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      value === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {value}
                    </span>
                  )
                }
              ]}
            />
          </div>
        )}

        {/* Capabilities Tab */}
        {activeTab === 'capabilities' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex space-x-4 overflow-x-auto">
                {[
                  { id: 'cap-hero', label: 'Hero', icon: 'ri-layout-top-line' },
                  { id: 'cap-research', label: 'Research', icon: 'ri-flask-line' },
                  { id: 'cap-facilities', label: 'Facilities', icon: 'ri-hospital-line', count: (data as any).capabilitiesFacilities?.length || 0 }
                ].map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveCapabilitiesSection(section.id)}
                    className={`flex items-center px-4 py-3 rounded-lg transition-colors whitespace-nowrap ${
                      activeCapabilitiesSection === section.id
                        ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                        : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <i className={`${section.icon} mr-2`}></i>
                    <span className="font-medium">{section.label}</span>
                    {section.count !== undefined && (
                      <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                        activeCapabilitiesSection === section.id ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-600'
                      }`}>
                        {section.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Capabilities: Hero */}
            {activeCapabilitiesSection === 'cap-hero' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Capabilities Hero Section</h3>
                  <button
                    onClick={() => {
                      setModalType('edit');
                      setEditingItem('capabilities-hero');
                      const heroData = (data as any).capabilitiesHero || {};
                      const formDataToSet = {
                        title: heroData.title || '',
                        subtitle: heroData.subtitle || '',
                        description: heroData.description || '',
                        subDescription: heroData.subDescription || '',
                        backgroundImage: heroData.backgroundImage || '',
                        isActive: heroData.isActive ?? true
                      };
                      setFormData(formDataToSet);
                      setShowModal(true);
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-edit-2-line mr-2"></i>
                    Edit Hero Section
                  </button>
                </div>

                {/* Preview Section */}
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Preview</h4>
                  </div>
                  
                  {/* Hero Preview */}
                  <div className="p-6">
                    <div className="relative h-60 w-full rounded overflow-hidden mb-6">
                      <img 
                        src={(data as any).capabilitiesHero?.backgroundImage || 'https://via.placeholder.com/800x400?text=Background+Image'} 
                        alt="Hero Background" 
                        className="w-full h-full object-cover" 
                      />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="text-center text-white px-4">
                          <h4 className="text-2xl md:text-3xl font-bold mb-2 font-montserrat">
                            {(data as any).capabilitiesHero?.title || 'Capabilities'}
                          </h4>
                          {(data as any).capabilitiesHero?.subtitle && (
                            <p className="text-lg font-montserrat mb-4">
                              {(data as any).capabilitiesHero.subtitle}
                            </p>
                          )}
                          
                          {/* Description Preview */}
                          {(data as any).capabilitiesHero?.description && (
                            <p className="text-sm text-white/90 max-w-2xl mx-auto leading-relaxed font-montserrat mb-2">
                              {(data as any).capabilitiesHero.description}
                            </p>
                          )}
                          
                          {/* Sub Description Preview */}
                          {(data as any).capabilitiesHero?.subDescription && (
                            <p className="text-xs text-white/80 max-w-3xl mx-auto font-montserrat">
                              {(data as any).capabilitiesHero.subDescription}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="text-sm font-semibold text-gray-700 mb-2">Content Details:</h5>
                        <div className="space-y-2">
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Title:</span> {(data as any).capabilitiesHero?.title || 'Not set'}
                          </p>
                          {(data as any).capabilitiesHero?.subtitle && (
                            <p className="text-sm text-gray-600">
                              <span className="font-medium">Subtitle:</span> {(data as any).capabilitiesHero.subtitle}
                            </p>
                          )}
                          {(data as any).capabilitiesHero?.description && (
                            <p className="text-sm text-gray-600">
                              <span className="font-medium">Description:</span> {(data as any).capabilitiesHero.description}
                            </p>
                          )}
                          {(data as any).capabilitiesHero?.subDescription && (
                            <p className="text-sm text-gray-600">
                              <span className="font-medium">Sub Description:</span> {(data as any).capabilitiesHero.subDescription}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Background Image:</span> 
                          <a href={(data as any).capabilitiesHero?.backgroundImage} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline ml-1">
                            View Image
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Capabilities: Research */}
            {activeCapabilitiesSection === 'cap-research' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-gray-800">Research & Development Excellence</h3>
                  <button
                    onClick={() => {
                      setModalType('edit');
                      setEditingItem('capabilities-research');
                      const researchData = (data as any).capabilitiesResearch || {};
                      console.log('Research Data:', researchData);
                      console.log('API Card Data:', researchData.apiCard);
                      const formDataToSet = {
                        title: researchData.title || '',
                        description: researchData.description || '',
                        image: researchData.image || '',
                        isActive: researchData.isActive ?? true,
                        apiCard: {
                          title: researchData.apiCard?.title || '',
                          subtitle: researchData.apiCard?.subtitle || '',
                          icon: researchData.apiCard?.icon || '',
                          color: researchData.apiCard?.color || '',
                          points: researchData.apiCard?.points || []
                        },
                        fdfCard: {
                          title: researchData.fdfCard?.title || '',
                          subtitle: researchData.fdfCard?.subtitle || '',
                          icon: researchData.fdfCard?.icon || '',
                          color: researchData.fdfCard?.color || '',
                          points: researchData.fdfCard?.points || []
                        },
                        promise: {
                          title: researchData.promise?.title || '',
                          description: researchData.promise?.description || '',
                          icon: researchData.promise?.icon || ''
                        }
                      };
                      console.log('Form Data to Set:', formDataToSet);
                      setFormData(formDataToSet);
                      setShowModal(true);
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    <i className="ri-edit-2-line mr-2"></i>
                    Edit Research Section
                  </button>
                </div>

                {/* Preview Section */}
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <div className="p-6 border-b border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">Preview</h4>
                  </div>
                  
                  {/* Main Title & Description */}
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-2xl font-bold text-gray-800 mb-3">
                      {(data as any).capabilitiesResearch?.title || 'Research & Development Excellence'}
                    </h2>
                    <p className="text-gray-600 leading-relaxed">
                      {(data as any).capabilitiesResearch?.description || 'At Refex Life Sciences, innovation is our engine of growth...'}
                    </p>
                  </div>

                  {/* Cards Preview */}
                  <div className="p-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* API Card Preview */}
                      <div className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`w-8 h-8 bg-[${(data as any).capabilitiesResearch?.apiCard?.color || '#2879b6'}] rounded-lg flex items-center justify-center`}>
                            <i className={`${(data as any).capabilitiesResearch?.apiCard?.icon || 'ri-flask-line'} text-white text-sm`}></i>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800 text-sm">
                              {(data as any).capabilitiesResearch?.apiCard?.title || 'API R&D Strengths'}
                            </h4>
                            <p className={`text-xs text-[${(data as any).capabilitiesResearch?.apiCard?.color || '#2879b6'}]`}>
                              {(data as any).capabilitiesResearch?.apiCard?.subtitle || 'Advanced Process Development'}
                            </p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          {((data as any).capabilitiesResearch?.apiCard?.points || []).slice(0, 3).map((point: any, index: number) => (
                            <div key={index} className="flex items-start gap-2">
                              <div className={`w-1 h-1 bg-[${(data as any).capabilitiesResearch?.apiCard?.color || '#2879b6'}] rounded-full mt-2 flex-shrink-0`}></div>
                              <div>
                                <p className="text-xs font-medium text-gray-800">{point.title}</p>
                                <p className="text-xs text-gray-600">{point.description}</p>
                              </div>
                            </div>
                          ))}
                          {((data as any).capabilitiesResearch?.apiCard?.points || []).length > 3 && (
                            <p className="text-xs text-gray-500">+{((data as any).capabilitiesResearch?.apiCard?.points || []).length - 3} more points</p>
                          )}
                        </div>
                      </div>

                      {/* FDF Card Preview */}
                      <div className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`w-8 h-8 bg-[${(data as any).capabilitiesResearch?.fdfCard?.color || '#7dc244'}] rounded-lg flex items-center justify-center`}>
                            <i className={`${(data as any).capabilitiesResearch?.fdfCard?.icon || 'ri-capsule-line'} text-white text-sm`}></i>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800 text-sm">
                              {(data as any).capabilitiesResearch?.fdfCard?.title || 'FDF R&D Strengths'}
                            </h4>
                            <p className={`text-xs text-[${(data as any).capabilitiesResearch?.fdfCard?.color || '#7dc244'}]`}>
                              {(data as any).capabilitiesResearch?.fdfCard?.subtitle || 'Complex Formulation Development'}
                            </p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          {((data as any).capabilitiesResearch?.fdfCard?.points || []).slice(0, 3).map((point: any, index: number) => (
                            <div key={index} className="flex items-start gap-2">
                              <div className={`w-1 h-1 bg-[${(data as any).capabilitiesResearch?.fdfCard?.color || '#7dc244'}] rounded-full mt-2 flex-shrink-0`}></div>
                              <div>
                                <p className="text-xs font-medium text-gray-800">{point.title}</p>
                                <p className="text-xs text-gray-600">{point.description}</p>
                              </div>
                            </div>
                          ))}
                          {((data as any).capabilitiesResearch?.fdfCard?.points || []).length > 3 && (
                            <p className="text-xs text-gray-500">+{((data as any).capabilitiesResearch?.fdfCard?.points || []).length - 3} more points</p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Promise Section Preview */}
                    <div className="mt-6 bg-gray-50 rounded-lg p-4 text-center">
                      <div className={`w-12 h-12 bg-[${(data as any).capabilitiesResearch?.fdfCard?.color || '#7dc244'}] rounded-lg flex items-center justify-center mx-auto mb-3`}>
                        <i className={`${(data as any).capabilitiesResearch?.promise?.icon || 'ri-lightbulb-line'} text-white`}></i>
                      </div>
                      <h4 className="font-semibold text-gray-800 text-sm mb-2">
                        {(data as any).capabilitiesResearch?.promise?.title || 'Our R&D Promise'}
                      </h4>
                      <p className="text-xs text-gray-600">
                        {(data as any).capabilitiesResearch?.promise?.description || 'Through a relentless focus on innovation...'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Capabilities: Facilities Table */}
            {activeCapabilitiesSection === 'cap-facilities' && (
            <DataTable
              title="Facilities"
              data={data.capabilitiesFacilities || []}
              columns={[
              
                {
                  key: 'image',
                  header: 'IMAGE',
                  render: (value: string) => (
                    <img src={value} alt="Facility" className="w-16 h-12 object-cover rounded border" />
                  )
                },
                { key: 'name', header: 'NAME' },
                { key: 'type', header: 'TYPE' },
                { key: 'location', header: 'LOCATION' },
                { key: 'capacity', header: 'CAPACITY' },
                { key: 'established', header: 'EST.' },
                {
                  key: 'capabilities',
                  header: 'CAPABILITIES',
                  render: (value: string[] = []) => Array.isArray(value) ? `${value.length}` : '0'
                },
                {
                  key: 'approvals',
                  header: 'APPROVALS',
                  render: (value: string[] = []) => Array.isArray(value) ? `${value.length}` : '0'
                },
                { key: 'order', header: 'ORDER' },
                {
                  key: 'isActive',
                  header: 'STATUS',
                  render: (value: boolean) => (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {value ? 'Active' : 'Inactive'}
                    </span>
                  )
                }
              ]}
            />
            )}
          </div>
        )}

        {/* Contact Page Tab */}
        {activeTab === 'contact-page' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Contact Page Management</h2>
            </div>

            {/* Contact Hero Section */}
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-gray-800">Contact Hero Section</h3>
                <button
                  onClick={() => {
                    setEditingItem('contact-hero');
                    const heroData = (data as any).contactHero || {};
                    const formDataToSet = {
                      title: heroData.title || '',
                      subtitle: heroData.subtitle || '',
                      description: heroData.description || '',
                      backgroundImage: heroData.backgroundImage || '',
                      isActive: heroData.isActive ?? true
                    };
                    setFormData(formDataToSet);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  <i className="ri-edit-line mr-2"></i>
                  Edit Hero Section
                </button>
              </div>

              {/* Preview Section */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="p-6 border-b border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Preview</h4>
                </div>
                
                {/* Hero Preview */}
                <div className="p-6">
                  <div className="relative h-60 w-full rounded overflow-hidden mb-6">
                    <img 
                      src={(data as any).contactHero?.backgroundImage || 'https://via.placeholder.com/800x400?text=Background+Image'} 
                      alt="Hero Background" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://via.placeholder.com/800x400?text=Image+Not+Available';
                      }}
                    />
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="text-center text-white px-4">
                        <h4 className="text-2xl md:text-3xl font-bold mb-2 font-montserrat">
                          {(data as any).contactHero?.title || 'Contact Us'}
                        </h4>
                        {(data as any).contactHero?.subtitle && (
                          <p className="text-lg font-montserrat mb-4">
                            {(data as any).contactHero.subtitle}
                          </p>
                        )}
                        
                        {/* Description Preview */}
                        {(data as any).contactHero?.description && (
                          <p className="text-sm text-white/90 max-w-2xl mx-auto leading-relaxed font-montserrat mb-2">
                            {(data as any).contactHero.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h5 className="text-sm font-semibold text-gray-700 mb-2">Content Details:</h5>
                      <div className="space-y-2">
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Title:</span> {(data as any).contactHero?.title || 'Not set'}
                        </p>
                        {(data as any).contactHero?.subtitle && (
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Subtitle:</span> {(data as any).contactHero.subtitle}
                          </p>
                        )}
                        {(data as any).contactHero?.description && (
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Description:</span> {(data as any).contactHero.description}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">Background Image:</span> 
                        <a href={(data as any).contactHero?.backgroundImage} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline ml-1">
                          View Image
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Sustainability Tab */}
        {activeTab === 'sustainability' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Sustainability Page Management</h2>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex space-x-4 overflow-x-auto">
                {[
                  { id: 'hero', label: 'Hero', icon: 'ri-image-line', count: 1 },
                  { id: 'sdg', label: 'UN SDGs', icon: 'ri-global-line', count: (sustainability.sdgCards || []).length },
                  { id: 'policies', label: 'Policies', icon: 'ri-shield-check-line', count: (sustainability.policies || []).length },
                  { id: 'vision', label: 'Vision & Mission', icon: 'ri-compass-3-line', count: ((sustainability.visionMission?.missionPoints||[]).length || 0) + 1 },
                  { id: 'innovation', label: 'Innovation & Transformation', icon: 'ri-cpu-line', count: ((sustainability.innovationAndTransformation?.digitalSolutions||[]).length + (sustainability.innovationAndTransformation?.researchInnovation||[]).length) },
                  { id: 'social', label: 'Social Responsibility', icon: 'ri-community-line', count: ((sustainability.socialResponsibility?.csrCards||[]).length + (sustainability.socialResponsibility?.csrImpactItems||[]).length) },
                  { id: 'footer', label: 'Footer Section', icon: 'ri-footprint-line', count: 1 }
                ].map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSustainabilitySection(section.id as any)}
                    className={`flex items-center px-4 py-3 rounded-lg transition-colors whitespace-nowrap ${
                      activeSustainabilitySection === section.id
                        ? 'bg-blue-100 text-blue-700 border-2 border-blue-200'
                        : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <i className={`${section.icon} mr-2`}></i>
                    <span className="font-medium">{section.label}</span>
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                      activeSustainabilitySection === section.id
                        ? 'bg-blue-200 text-blue-800'
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {section.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {activeSustainabilitySection === 'hero' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="bg-white rounded-xl shadow-lg p-6 space-y-4">
                  <div>
                    <label className="block text-sm text-gray-600">Title</label>
                    <input className="mt-1 w-full border rounded px-3 py-2" value={sustHeroTitle} onChange={(e) => setSustHeroTitle(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600">Description</label>
                    <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={sustHeroDescription} onChange={(e) => setSustHeroDescription(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600">Background Image URL</label>
                    <input className="mt-1 w-full border rounded px-3 py-2" value={sustHeroBg} onChange={(e) => setSustHeroBg(e.target.value)} />
                  </div>
                  <div>
                    <button onClick={saveSustainabilityHero} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Save Hero</button>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-lg p-0 overflow-hidden">
                  <div
                    className="relative p-8 min-h-[260px] flex items-center justify-center text-center bg-cover bg-center"
                    style={{
                      backgroundImage: `linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.35)), url('${sustHeroBg || sustainability.hero?.backgroundImage || ''}')`
                    }}
                  >
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-3">{sustHeroTitle || 'Preview Title'}</h3>
                      <p className="text-white/90 max-w-xl mx-auto">{sustHeroDescription || 'Preview description will appear here.'}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
               {activeSustainabilitySection === 'social' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Social Responsibility - Section</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-sm text-gray-600">Section Title</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.socialResponsibility?.sectionTitle)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), sectionTitle: e.target.value } })} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Active</span>
                      <div>
                        <input type="checkbox" checked={!!(sustainability.socialResponsibility?.isActive ?? true)} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), isActive: e.target.checked } })} />
                      </div>
                    </label>
                    <label className="block md:col-span-2">
                      <span className="text-sm text-gray-600">Section Description (rich text)</span>
                      <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={(sustainability.socialResponsibility?.sectionDescription)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), sectionDescription: e.target.value } })} />
                    </label>
                  </div>
                </div>

                {/* CSR Cards */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">CSR Cards</h3>
                    <button onClick={() => {
                      const existing = (sustainability.socialResponsibility?.csrCards||[]);
                      const next = [ ...existing, { id: `csr-${Date.now()}`, cardTitle: 'New Title', cardSubtitle: '', cardDescription: '', highlightText: '', icon: 'ri-star-line', gradientColors: '#2879b6,#3a8bc4', isActive: true, order: (existing.length||0)+1 } ];
                      (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: next } });
                    }} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Card
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Subtitle</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Highlight</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Icon</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Gradient</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {(sustainability.socialResponsibility?.csrCards||[]).slice().sort((a: any, b: any) => (a.order||0)-(b.order||0)).map((c: any) => (
                          <tr key={c.id} className="align-top">
                            <td className="px-3 py-2 min-w-[180px]"><input className="w-full border rounded px-2 py-1" value={c.cardTitle} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, cardTitle: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 min-w-[160px]"><input className="w-full border rounded px-2 py-1" value={c.cardSubtitle||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, cardSubtitle: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 min-w-[180px]"><input className="w-full border rounded px-2 py-1" value={c.highlightText||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, highlightText: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-44"><input className="w-full border rounded px-2 py-1" value={c.icon||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, icon: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-56"><input className="w-full border rounded px-2 py-1" value={c.gradientColors||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, gradientColors: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-24"><input type="number" className="w-full border rounded px-2 py-1" value={c.order||0} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, order: Number(e.target.value)||0 }: x) } })} /></td>
                            <td className="px-3 py-2 w-24"><input type="checkbox" checked={!!c.isActive} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).map((x: any) => x.id===c.id? { ...x, isActive: e.target.checked }: x) } })} /></td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button onClick={() => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrCards: (sustainability.socialResponsibility?.csrCards||[]).filter((x: any) => x.id !== c.id) } })} className="text-red-600 hover:text-red-700"><i className="ri-delete-bin-6-line"></i></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* CSR Impact */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">CSR Impact</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <label className="block">
                      <span className="text-sm text-gray-600">Impact Title</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.socialResponsibility?.csrImpactTitle)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactTitle: e.target.value } })} />
                    </label>
                    <label className="block md:col-span-2">
                      <span className="text-sm text-gray-600">Impact Description (rich text)</span>
                      <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={(sustainability.socialResponsibility?.csrImpactDescription)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactDescription: e.target.value } })} />
                    </label>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-semibold">Impact Items</h4>
                    <button onClick={() => {
                      const existing = (sustainability.socialResponsibility?.csrImpactItems||[]);
                      const next = [ ...existing, { id: `csri-${Date.now()}`, title: 'Title', description: '', icon: 'ri-star-line', gradientColors: '#2879b6,#3a8bc4', isActive: true, order: (existing.length||0)+1 } ];
                      (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: next } });
                    }} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Impact Item
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Description</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Icon</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Gradient</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {(sustainability.socialResponsibility?.csrImpactItems||[]).slice().sort((a: any, b: any) => (a.order||0)-(b.order||0)).map((it: any) => (
                          <tr key={it.id} className="align-top">
                            <td className="px-3 py-2 min-w-[180px]"><input className="w-full border rounded px-2 py-1" value={it.title} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, title: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 min-w-[260px]"><textarea className="w-full border rounded px-2 py-1 h-16" value={it.description||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, description: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-44"><input className="w-full border rounded px-2 py-1" value={it.icon||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, icon: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-56"><input className="w-full border rounded px-2 py-1" value={it.gradientColors||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, gradientColors: e.target.value }: x) } })} /></td>
                            <td className="px-3 py-2 w-24"><input type="number" className="w-full border rounded px-2 py-1" value={it.order||0} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, order: Number(e.target.value)||0 }: x) } })} /></td>
                            <td className="px-3 py-2 w-24"><input type="checkbox" checked={!!it.isActive} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).map((x: any) => x.id===it.id? { ...x, isActive: e.target.checked }: x) } })} /></td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button onClick={() => (updateData as any)('sustainability', { ...sustainability, socialResponsibility: { ...(sustainability.socialResponsibility||{}), csrImpactItems: (sustainability.socialResponsibility?.csrImpactItems||[]).filter((x: any) => x.id !== it.id) } })} className="text-red-600 hover:text-red-700"><i className="ri-delete-bin-6-line"></i></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeSustainabilitySection === 'vision' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="bg-white rounded-xl shadow-lg p-6 space-y-6">
                  <h3 className="text-xl font-semibold text-gray-800">Vision & Mission</h3>

                  {/* Titles & Subtitles */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-sm text-gray-600">Section Title</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.sectionTitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), sectionTitle: e.target.value } })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Section Subtitle</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.sectionSubtitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), sectionSubtitle: e.target.value } })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Vision Title</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.visionTitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionTitle: e.target.value } })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Vision Subtitle</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.visionSubtitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionSubtitle: e.target.value } })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Mission Title</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.missionTitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), missionTitle: e.target.value } })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Mission Subtitle</span>
                      <input
                        className="mt-1 w-full border rounded px-3 py-2"
                        value={(sustainability.visionMission?.missionSubtitle) || ''}
                        onChange={(e) => (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), missionSubtitle: e.target.value } })}
                      />
                    </label>
                  </div>

                  {/* Vision Description */}
                  <div>
                    <label className="block text-sm text-gray-600">Vision Description</label>
                    <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={vmVisionDesc} onChange={(e) => setVmVisionDesc(e.target.value)} />
                    <div className="flex justify-end mt-2">
                      <button onClick={saveVisionDesc} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Save Vision</button>
                    </div>
                  </div>

                  {/* Mission Points */}
                  <div className="flex items-center justify-between mt-4">
                    <h4 className="text-lg font-semibold">Mission Points</h4>
                    <button onClick={() => openMpModal('add')} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Mission Point
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Text</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {missionPointsSorted.map((mp: any) => (
                          <tr key={mp.id}>
                            <td className="px-3 py-2 min-w-[260px]"><div className="line-clamp-2">{mp.text}</div></td>
                            <td className="px-3 py-2 w-24">{mp.order}</td>
                            <td className="px-3 py-2 w-24">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${mp.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{mp.isActive ? 'Active' : 'Inactive'}</span>
                            </td>
                            <td className="px-3 py-2 w-32 text-right space-x-2">
                              <button onClick={() => openMpModal('edit', mp)} className="text-blue-600 hover:text-blue-700"><i className="ri-edit-2-line"></i></button>
                              <button onClick={() => deleteMissionPoint(mp.id)} className="text-red-600 hover:text-red-700"><i className="ri-delete-bin-6-line"></i></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Vision Points */}
                  <div className="flex items-center justify-between mt-8">
                    <h4 className="text-lg font-semibold">Vision Points</h4>
                    <button
                      onClick={() => {
                        const existing = (sustainability.visionMission?.visionPoints || []);
                        const next = [
                          ...existing,
                          { id: `vp-${Date.now()}`, icon: 'ri-check-line', text: 'New vision point', color: '#2879b6', order: (existing.length || 0) + 1, isActive: true }
                        ];
                        (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: next } });
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                    >
                      <i className="ri-add-line mr-2"></i>
                      Add Vision Point
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Icon</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Text</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Color</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {(sustainability.visionMission?.visionPoints || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0)).map((vp: any) => (
                          <tr key={vp.id} className="align-top">
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={vp.icon}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).map((p: any) => p.id === vp.id ? { ...p, icon: e.target.value } : p);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 min-w-[260px]">
                              <textarea className="w-full border rounded px-2 py-1 h-16" value={vp.text}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).map((p: any) => p.id === vp.id ? { ...p, text: e.target.value } : p);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={vp.color}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).map((p: any) => p.id === vp.id ? { ...p, color: e.target.value } : p);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="number" className="w-full border rounded px-2 py-1" value={vp.order}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).map((p: any) => p.id === vp.id ? { ...p, order: Number(e.target.value)||0 } : p);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="checkbox" checked={!!vp.isActive}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).map((p: any) => p.id === vp.id ? { ...p, isActive: e.target.checked } : p);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button
                                onClick={() => {
                                  const updated = (sustainability.visionMission?.visionPoints || []).filter((p: any) => p.id !== vp.id);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), visionPoints: updated } });
                                }}
                                className="text-red-600 hover:text-red-700"
                              >
                                <i className="ri-delete-bin-6-line"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between mt-8">
                    <h4 className="text-lg font-semibold">Stats</h4>
                    <button
                      onClick={() => {
                        const existing = (sustainability.visionMission?.stats || []);
                        const next = [
                          ...existing,
                          { id: `vs-${Date.now()}`, label: 'Label', value: '0', color: '#2879b6', order: (existing.length || 0) + 1, isActive: true }
                        ];
                        (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: next } });
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium"
                    >
                      <i className="ri-add-line mr-2"></i>
                      Add Stat
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Label</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Value</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Color</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {(sustainability.visionMission?.stats || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0)).map((st: any) => (
                          <tr key={st.id} className="align-top">
                            <td className="px-3 py-2 min-w-[200px]">
                              <input className="w-full border rounded px-2 py-1" value={st.label}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.stats || []).map((s: any) => s.id === st.id ? { ...s, label: e.target.value } : s);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={st.value}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.stats || []).map((s: any) => s.id === st.id ? { ...s, value: e.target.value } : s);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={st.color}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.stats || []).map((s: any) => s.id === st.id ? { ...s, color: e.target.value } : s);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="number" className="w-full border rounded px-2 py-1" value={st.order}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.stats || []).map((s: any) => s.id === st.id ? { ...s, order: Number(e.target.value)||0 } : s);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="checkbox" checked={!!st.isActive}
                                onChange={(e) => {
                                  const updated = (sustainability.visionMission?.stats || []).map((s: any) => s.id === st.id ? { ...s, isActive: e.target.checked } : s);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }} />
                            </td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button
                                onClick={() => {
                                  const updated = (sustainability.visionMission?.stats || []).filter((s: any) => s.id !== st.id);
                                  (updateData as any)('sustainability', { ...sustainability, visionMission: { ...(sustainability.visionMission || {}), stats: updated } });
                                }}
                                className="text-red-600 hover:text-red-700"
                              >
                                <i className="ri-delete-bin-6-line"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">Preview</h3>
                  <div className="space-y-6">
                    <div className="rounded-3xl border p-6">
                      <h4 className="text-xl font-bold text-gray-800 mb-1">{sustainability.visionMission?.visionTitle || 'Our Vision'}</h4>
                      <p className="text-sm text-gray-600 mb-4">{sustainability.visionMission?.visionSubtitle || 'Sustainable Healthcare Partner'}</p>
                      <p className="text-gray-700">{vmVisionDesc || 'Vision description preview...'}</p>
                    </div>
                    <div className="rounded-3xl border p-6">
                      <h4 className="text-xl font-bold text-gray-800 mb-1">{sustainability.visionMission?.missionTitle || 'Our Mission'}</h4>
                      <p className="text-sm text-gray-600 mb-4">{sustainability.visionMission?.missionSubtitle || 'Impactful Solutions'}</p>
                      <div className="space-y-3">
                        {missionPointsSorted.map((mp: any) => (
                          <div key={mp.id} className="flex items-start gap-3 p-3 bg-gradient-to-r from-[#7dc244]/5 to-transparent rounded-xl border">
                            <div className="w-6 h-6 bg-[#7dc244] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                              <i className="ri-check-line text-white text-sm"></i>
                            </div>
                            <p className="text-gray-700 text-sm leading-relaxed">{mp.text}</p>
                          </div>
                        ))}
                      </div>
                      <div className="flex items-center justify-center gap-6 pt-4 border-t border-[#7dc244]/10 mt-6">
                        {(sustainability.visionMission?.stats || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0)).filter((s: any) => s.isActive).map((s: any) => (
                          <div key={s.id} className="text-center">
                            <div className="text-lg font-bold" style={{ color: s.color }}>{s.value}</div>
                            <div className="text-xs text-gray-600">{s.label}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mission Point Modal */}
                {mpModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">{mpMode === 'add' ? 'Add Mission Point' : 'Edit Mission Point'}</h3>
                        <button onClick={closeMpModal} className="text-gray-500 hover:text-gray-700"><i className="ri-close-line text-xl"></i></button>
                      </div>
                      <div className="grid grid-cols-1 gap-4">
                        <label className="block">
                          <span className="text-sm text-gray-600">Text</span>
                          <textarea className="mt-1 w-full border rounded px-3 py-2 h-24" value={mpForm.text} onChange={(e) => setMpForm({ ...mpForm, text: e.target.value })} />
                        </label>
                        <label className="block">
                          <span className="text-sm text-gray-600">Order</span>
                          <input type="number" className="mt-1 w-full border rounded px-3 py-2" value={mpForm.order} onChange={(e) => setMpForm({ ...mpForm, order: e.target.value })} />
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" checked={!!mpForm.isActive} onChange={(e) => setMpForm({ ...mpForm, isActive: e.target.checked })} />
                          <span className="text-sm text-gray-700">Active</span>
                        </label>
                      </div>
                      <div className="flex justify-end mt-6 space-x-3">
                        <button onClick={closeMpModal} className="px-4 py-2 rounded border">Cancel</button>
                        <button onClick={saveMpModal} className="px-4 py-2 rounded bg-blue-600 text-white">Save</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
            {activeSustainabilitySection === 'sdg' && (
              <div className="space-y-6">
                {/* Preview first */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">UN SDGs Preview</h3>
                  <div className="grid grid-cols-1 gap-4">
                    {sdgCardsSorted.map((card: any) => (
                      <div key={card.id} className="rounded-xl border p-4 flex items-start gap-4">
                        <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white" style={{ backgroundColor: card.color }}>
                          <i className={`${card.icon} text-xl`}></i>
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold">SDG {card.number}: {card.title}</div>
                          <div className="text-sm text-gray-600 mt-1">{card.contribution}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Table second */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">UN SDG Cards</h3>
                    <button onClick={addSdgCard} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add SDG Card
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">#</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Contribution</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Icon</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Color</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {sdgCardsSorted.map((card: any) => (
                          <tr key={card.id} className="align-top">
                            <td className="px-3 py-2 w-20">{card.number}</td>
                            <td className="px-3 py-2 min-w-[180px]">{card.title}</td>
                            <td className="px-3 py-2 min-w-[260px]"><div className="line-clamp-3 text-gray-700">{card.contribution}</div></td>
                            <td className="px-3 py-2 w-40">{card.icon}</td>
                            <td className="px-3 py-2 w-40">{card.color}</td>
                            <td className="px-3 py-2 w-24">{card.order}</td>
                            <td className="px-3 py-2 w-24">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${card.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{card.isActive ? 'Active' : 'Inactive'}</span>
                            </td>
                            <td className="px-3 py-2 w-32 text-right space-x-2">
                              <button onClick={() => openSdgModal('edit', card)} className="text-blue-600 hover:text-blue-700">
                                <i className="ri-edit-2-line"></i>
                              </button>
                              <button onClick={() => deleteSdgCard(card.id)} className="text-red-600 hover:text-red-700">
                                <i className="ri-delete-bin-6-line"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                {/* SDG Modal */}
                {sdgModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">{sdgModalMode === 'add' ? 'Add SDG Card' : 'Edit SDG Card'}</h3>
                        <button onClick={closeSdgModal} className="text-gray-500 hover:text-gray-700"><i className="ri-close-line text-xl"></i></button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label className="block">
                          <span className="text-sm text-gray-600">SDG Number</span>
                          <input type="number" className="mt-1 w-full border rounded px-3 py-2" value={sdgForm.number} onChange={(e) => setSdgForm({ ...sdgForm, number: e.target.value })} />
                        </label>
                        <label className="block">
                          <span className="text-sm text-gray-600">Order</span>
                          <input type="number" className="mt-1 w-full border rounded px-3 py-2" value={sdgForm.order} onChange={(e) => setSdgForm({ ...sdgForm, order: e.target.value })} />
                        </label>
                        <label className="block md:col-span-2">
                          <span className="text-sm text-gray-600">Title</span>
                          <input className="mt-1 w-full border rounded px-3 py-2" value={sdgForm.title} onChange={(e) => setSdgForm({ ...sdgForm, title: e.target.value })} />
                        </label>
                        <label className="block md:col-span-2">
                          <span className="text-sm text-gray-600">Contribution</span>
                          <textarea className="mt-1 w-full border rounded px-3 py-2 h-24" value={sdgForm.contribution} onChange={(e) => setSdgForm({ ...sdgForm, contribution: e.target.value })} />
                        </label>
                        <label className="block">
                          <span className="text-sm text-gray-600">Icon</span>
                          <input className="mt-1 w-full border rounded px-3 py-2" value={sdgForm.icon} onChange={(e) => setSdgForm({ ...sdgForm, icon: e.target.value })} />
                        </label>
                        <label className="block">
                          <span className="text-sm text-gray-600">Color</span>
                          <input className="mt-1 w-full border rounded px-3 py-2" value={sdgForm.color} onChange={(e) => setSdgForm({ ...sdgForm, color: e.target.value })} />
                        </label>
                        <label className="flex items-center space-x-2 md:col-span-2">
                          <input type="checkbox" checked={!!sdgForm.isActive} onChange={(e) => setSdgForm({ ...sdgForm, isActive: e.target.checked })} />
                          <span className="text-sm text-gray-700">Active</span>
                        </label>
                      </div>
                      <div className="flex justify-end mt-6 space-x-3">
                        <button onClick={closeSdgModal} className="px-4 py-2 rounded border">Cancel</button>
                        <button onClick={saveSdgModal} className="px-4 py-2 rounded bg-blue-600 text-white">Save</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
            {activeSustainabilitySection === 'innovation' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Innovation & Transformation - Section</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-sm text-gray-600">Section Title</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={it.sectionTitle || ''} onChange={(e) => setItField('sectionTitle', e.target.value)} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Active</span>
                      <div>
                        <input type="checkbox" checked={!!(it.isActive ?? true)} onChange={(e) => setItField('isActive', e.target.checked)} />
                      </div>
                    </label>
                    <label className="block md:col-span-2">
                      <span className="text-sm text-gray-600">Section Description (rich text)</span>
                      <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={it.sectionDescription || ''} onChange={(e) => setItField('sectionDescription', e.target.value)} />
                    </label>
                  </div>
                </div>

                {/* Digital Solutions */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">Digital Solutions</h3>
                    <button onClick={addDigitalCard} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Card
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Subtitle</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Description</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {digitalSolutionsSorted.map((c: any) => (
                          <tr key={c.id} className="align-top">
                            <td className="px-3 py-2 min-w-[180px]"><input className="w-full border rounded px-2 py-1" value={c.cardTitle} onChange={(e) => updateDigitalField(c.id, 'cardTitle', e.target.value)} /></td>
                            <td className="px-3 py-2 min-w-[160px]"><input className="w-full border rounded px-2 py-1" value={c.cardSubtitle||''} onChange={(e) => updateDigitalField(c.id, 'cardSubtitle', e.target.value)} /></td>
                            <td className="px-3 py-2 min-w-[260px]"><textarea className="w-full border rounded px-2 py-1 h-16" value={c.cardDescription||''} onChange={(e) => updateDigitalField(c.id, 'cardDescription', e.target.value)} /></td>
                            <td className="px-3 py-2 w-24"><input type="number" className="w-full border rounded px-2 py-1" value={c.order||0} onChange={(e) => updateDigitalField(c.id, 'order', e.target.value)} /></td>
                            <td className="px-3 py-2 w-24"><input type="checkbox" checked={!!c.isActive} onChange={(e) => updateDigitalField(c.id, 'isActive', e.target.checked)} /></td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button onClick={() => deleteDigitalCard(c.id)} className="text-red-600 hover:text-red-700"><i className="ri-delete-bin-6-line"></i></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Research & Innovation */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">Research & Innovation</h3>
                    <button onClick={addResearchCard} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Card
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Subtitle</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Description</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {researchInnovationSorted.map((c: any) => (
                          <tr key={c.id} className="align-top">
                            <td className="px-3 py-2 min-w-[180px]"><input className="w-full border rounded px-2 py-1" value={c.cardTitle} onChange={(e) => updateResearchField(c.id, 'cardTitle', e.target.value)} /></td>
                            <td className="px-3 py-2 min-w-[160px]"><input className="w-full border rounded px-2 py-1" value={c.cardSubtitle||''} onChange={(e) => updateResearchField(c.id, 'cardSubtitle', e.target.value)} /></td>
                            <td className="px-3 py-2 min-w-[260px]"><textarea className="w-full border rounded px-2 py-1 h-16" value={c.cardDescription||''} onChange={(e) => updateResearchField(c.id, 'cardDescription', e.target.value)} /></td>
                            <td className="px-3 py-2 w-24"><input type="number" className="w-full border rounded px-2 py-1" value={c.order||0} onChange={(e) => updateResearchField(c.id, 'order', e.target.value)} /></td>
                            <td className="px-3 py-2 w-24"><input type="checkbox" checked={!!c.isActive} onChange={(e) => updateResearchField(c.id, 'isActive', e.target.checked)} /></td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button onClick={() => deleteResearchCard(c.id)} className="text-red-600 hover:text-red-700"><i className="ri-delete-bin-6-line"></i></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeSustainabilitySection === 'policies' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-800">Policies</h3>
                    <button onClick={addPolicy} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                      <i className="ri-add-line mr-2"></i>
                      Add Policy
                    </button>
                  </div>
                  <div className="overflow-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Title</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Description</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Icon</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Color</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Order</th>
                          <th className="px-3 py-2 text-left font-medium text-gray-700">Active</th>
                          <th className="px-3 py-2"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {(sustainability.policies || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0)).map((pol: any) => (
                          <tr key={pol.id} className="align-top">
                            <td className="px-3 py-2 min-w-[180px]">
                              <input className="w-full border rounded px-2 py-1" value={pol.title} onChange={(e) => updatePolicyField(pol.id, 'title', e.target.value)} />
                            </td>
                            <td className="px-3 py-2 min-w-[260px]">
                              <textarea className="w-full border rounded px-2 py-1 h-16" value={pol.description} onChange={(e) => updatePolicyField(pol.id, 'description', e.target.value)} />
                            </td>
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={pol.icon} onChange={(e) => updatePolicyField(pol.id, 'icon', e.target.value)} />
                            </td>
                            <td className="px-3 py-2 w-40">
                              <input className="w-full border rounded px-2 py-1" value={pol.color} onChange={(e) => updatePolicyField(pol.id, 'color', e.target.value)} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="number" className="w-full border rounded px-2 py-1" value={pol.order} onChange={(e) => updatePolicyField(pol.id, 'order', e.target.value)} />
                            </td>
                            <td className="px-3 py-2 w-24">
                              <input type="checkbox" checked={!!pol.isActive} onChange={(e) => updatePolicyField(pol.id, 'isActive', e.target.checked)} />
                            </td>
                            <td className="px-3 py-2 w-24 text-right">
                              <button onClick={() => deletePolicy(pol.id)} className="text-red-600 hover:text-red-700">
                                <i className="ri-delete-bin-6-line"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">Policies Preview</h3>
                  <div className="space-y-3">
                    {(sustainability.policies || []).slice().sort((a: any, b: any) => (a.order||0) - (b.order||0)).map((pol: any) => (
                      <div key={pol.id} className="flex items-start gap-3 border rounded-lg p-3">
                        <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white" style={{ backgroundColor: pol.color }}>
                          <i className={`${pol.icon}`}></i>
                        </div>
                        <div>
                          <div className="font-medium">{pol.title}</div>
                          <div className="text-sm text-gray-600">{pol.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
                 {activeSustainabilitySection === 'footer' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Footer Section (Final Hero)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="block">
                      <span className="text-sm text-gray-600">Title</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.footerSection?.title)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), title: e.target.value } })} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">CTA Text</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.footerSection?.ctaText)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), ctaText: e.target.value } })} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">CTA Icon (e.g., ri-heart-pulse-line)</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.footerSection?.ctaIcon)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), ctaIcon: e.target.value } })} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Background Image URL</span>
                      <input className="mt-1 w-full border rounded px-3 py-2" value={(sustainability.footerSection?.backgroundImageUrl)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), backgroundImageUrl: e.target.value } })} />
                    </label>
                    <label className="block md:col-span-2">
                      <span className="text-sm text-gray-600">Subtitle (rich text)</span>
                      <textarea className="mt-1 w-full border rounded px-3 py-2 h-28" value={(sustainability.footerSection?.subtitle)||''} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), subtitle: e.target.value } })} />
                    </label>
                    <label className="block">
                      <span className="text-sm text-gray-600">Active</span>
                      <div>
                        <input type="checkbox" checked={!!(sustainability.footerSection?.isActive ?? true)} onChange={(e) => (updateData as any)('sustainability', { ...sustainability, footerSection: { ...(sustainability.footerSection||{}), isActive: e.target.checked } })} />
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Users Management</h2>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                <i className="ri-add-line mr-2"></i>
                Add User
              </button>
            </div>
            <DataTable
              title="Users"
              data={data.users}
              columns={[
                { key: 'name', header: 'Name' },
                { key: 'email', header: 'Email' },
                { key: 'role', header: 'Role' },
                { 
                  key: 'status', 
                  header: 'Status',
                  render: (value: string) => (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      value === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {value}
                    </span>
                  )
                }
              ]}
            />

            {/* Contact Get in Touch Section */}
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-gray-800">Get in Touch Section</h3>
                <button
                  onClick={() => {
                    setEditingItem('contact-get-in-touch');
                    const getInTouchData = (data as any).contactGetInTouch || {};
                    const formDataToSet = {
                      title: getInTouchData.title || '',
                      description: getInTouchData.description || '',
                      locationTitle: getInTouchData.location?.title || '',
                      locationAddress: getInTouchData.location?.address || '',
                      locationIcon: getInTouchData.location?.icon || '',
                      locationColor: getInTouchData.location?.color || '',
                      phoneTitle: getInTouchData.phone?.title || '',
                      phoneNumber: getInTouchData.phone?.number || '',
                      phoneHours: getInTouchData.phone?.hours || '',
                      phoneIcon: getInTouchData.phone?.icon || '',
                      phoneColor: getInTouchData.phone?.color || '',
                      emailTitle: getInTouchData.email?.title || '',
                      emailAddress: getInTouchData.email?.address || '',
                      emailResponseTime: getInTouchData.email?.responseTime || '',
                      emailIcon: getInTouchData.email?.icon || '',
                      emailColor: getInTouchData.email?.color || '',
                      businessHoursTitle: getInTouchData.businessHours?.title || '',
                      businessHoursMondayFriday: getInTouchData.businessHours?.mondayFriday || '',
                      businessHoursSaturday: getInTouchData.businessHours?.saturday || '',
                      businessHoursSunday: getInTouchData.businessHours?.sunday || '',
                      isActive: getInTouchData.isActive ?? true
                    };
                    setFormData(formDataToSet);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  <i className="ri-edit-line mr-2"></i>
                  Edit Get in Touch Section
                </button>
              </div>

              {/* Preview Section */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="p-6 border-b border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Preview</h4>
                </div>
                
                {/* Get in Touch Preview */}
                <div className="p-6">
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-2xl font-bold text-gray-900 mb-4 font-montserrat">
                        {(data as any).contactGetInTouch?.title || 'Get in Touch'}
                      </h4>
                      <p className="text-lg text-gray-600 leading-relaxed font-montserrat">
                        {(data as any).contactGetInTouch?.description || 'Description not set'}
                      </p>
                    </div>

                    {/* Contact Details Preview */}
                    <div className="space-y-6">
                      {/* Location */}
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          (data as any).contactGetInTouch?.location?.color === 'refex-blue' ? 'bg-blue-600' :
                          (data as any).contactGetInTouch?.location?.color === 'refex-green' ? 'bg-green-600' :
                          'bg-orange-600'
                        }`}>
                          <i className={`${(data as any).contactGetInTouch?.location?.icon || 'ri-map-pin-line'} text-white text-xl`}></i>
                        </div>
                        <div>
                          <h5 className="text-lg font-semibold text-gray-900 mb-2 font-montserrat">
                            {(data as any).contactGetInTouch?.location?.title || 'Our Location'}
                          </h5>
                          <p className="text-gray-600 font-montserrat" dangerouslySetInnerHTML={{
                            __html: (data as any).contactGetInTouch?.location?.address || 'Address not set'
                          }}></p>
                        </div>
                      </div>

                      {/* Phone */}
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          (data as any).contactGetInTouch?.phone?.color === 'refex-blue' ? 'bg-blue-600' :
                          (data as any).contactGetInTouch?.phone?.color === 'refex-green' ? 'bg-green-600' :
                          'bg-orange-600'
                        }`}>
                          <i className={`${(data as any).contactGetInTouch?.phone?.icon || 'ri-phone-line'} text-white text-xl`}></i>
                        </div>
                        <div>
                          <h5 className="text-lg font-semibold text-gray-900 mb-2 font-montserrat">
                            {(data as any).contactGetInTouch?.phone?.title || 'Phone'}
                          </h5>
                          <p className="text-gray-600 font-montserrat">
                            {(data as any).contactGetInTouch?.phone?.number || 'Phone number not set'}
                          </p>
                          <p className="text-sm text-gray-500 font-montserrat">
                            {(data as any).contactGetInTouch?.phone?.hours || 'Hours not set'}
                          </p>
                        </div>
                      </div>

                      {/* Email */}
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          (data as any).contactGetInTouch?.email?.color === 'refex-blue' ? 'bg-blue-600' :
                          (data as any).contactGetInTouch?.email?.color === 'refex-green' ? 'bg-green-600' :
                          'bg-orange-600'
                        }`}>
                          <i className={`${(data as any).contactGetInTouch?.email?.icon || 'ri-mail-line'} text-white text-xl`}></i>
                        </div>
                        <div>
                          <h5 className="text-lg font-semibold text-gray-900 mb-2 font-montserrat">
                            {(data as any).contactGetInTouch?.email?.title || 'Email'}
                          </h5>
                          <p className="text-gray-600 font-montserrat">
                            {(data as any).contactGetInTouch?.email?.address || 'Email address not set'}
                          </p>
                          <p className="text-sm text-gray-500 font-montserrat">
                            {(data as any).contactGetInTouch?.email?.responseTime || 'Response time not set'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Business Hours Preview */}
                    <div className="bg-gray-50 rounded-xl p-6">
                      <h5 className="text-lg font-semibold text-gray-900 mb-4 font-montserrat">
                        {(data as any).contactGetInTouch?.businessHours?.title || 'Business Hours'}
                      </h5>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600 font-montserrat">Monday - Friday</span>
                          <span className="text-gray-900 font-semibold font-montserrat">
                            {(data as any).contactGetInTouch?.businessHours?.mondayFriday || 'Not set'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 font-montserrat">Saturday</span>
                          <span className="text-gray-900 font-semibold font-montserrat">
                            {(data as any).contactGetInTouch?.businessHours?.saturday || 'Not set'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 font-montserrat">Sunday</span>
                          <span className="text-gray-900 font-semibold font-montserrat">
                            {(data as any).contactGetInTouch?.businessHours?.sunday || 'Not set'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Users Section */}
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-gray-800">Contact Users</h3>
                <button
                  onClick={() => {
                    setModalType('add');
                    setEditingItem('contact-user');
                    setFormData({
                      name: '',
                      email: '',
                      phone: '',
                      department: '',
                      position: '',
                      avatar: '',
                      isActive: true,
                      order: (data as any).contactUsers?.length || 0
                    });
                    setShowModal(true);
                  }}
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  <i className="ri-add-line mr-2"></i>
                  Add User
                </button>
              </div>

              {/* Users Preview */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="p-6 border-b border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Users Preview</h4>
                </div>
                
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {((data as any).contactUsers || [])
                      .filter((user: any) => user.isActive)
                      .sort((a: any, b: any) => a.order - b.order)
                      .map((user: any, index: number) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-center space-x-3 mb-3">
                          <img 
                            src={user.avatar || 'https://via.placeholder.com/50x50?text=User'} 
                            alt={user.name}
                            className="w-12 h-12 rounded-full object-cover"
                            onError={(e) => {
                              e.currentTarget.src = 'https://via.placeholder.com/50x50?text=User';
                            }}
                          />
                          <div>
                            <h5 className="font-semibold text-gray-800 text-sm">{user.name}</h5>
                            <p className="text-xs text-gray-600">{user.position}</p>
                          </div>
                        </div>
                        <div className="space-y-1 text-xs text-gray-600">
                          <p><span className="font-medium">Department:</span> {user.department}</p>
                          <p><span className="font-medium">Email:</span> {user.email}</p>
                          <p><span className="font-medium">Phone:</span> {user.phone}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Users Data Table */}
              <DataTable
                title="Contact Users"
                data={(data as any).contactUsers || []}
                columns={[
                  {
                    key: 'avatar',
                    header: 'Avatar',
                    render: (value: string, item: any) => (
                      <img 
                        src={value || 'https://via.placeholder.com/40x40?text=User'} 
                        alt={item.name}
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/40x40?text=User';
                        }}
                      />
                    )
                  },
                  { key: 'name', header: 'Name' },
                  { key: 'email', header: 'Email' },
                  { key: 'phone', header: 'Phone' },
                  { key: 'department', header: 'Department' },
                  { key: 'position', header: 'Position' },
                  { key: 'order', header: 'Order' },
                  { 
                    key: 'isActive', 
                    header: 'Status',
                    render: (value: boolean) => (
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {value ? 'Active' : 'Inactive'}
                      </span>
                    )
                  }
                ]}
                onEdit={(item: any) => {
                  setModalType('edit');
                  setEditingItem('contact-user');
                  setFormData({
                    id: item.id,
                    name: item.name || '',
                    email: item.email || '',
                    phone: item.phone || '',
                    department: item.department || '',
                    position: item.position || '',
                    avatar: item.avatar || '',
                    isActive: item.isActive ?? true,
                    order: item.order || 0
                  });
                  setShowModal(true);
                }}
                onDelete={(item: any) => {
                  const updatedUsers = ((data as any).contactUsers || []).filter((u: any) => u.id !== item.id);
                  updateData('contactUsers' as any, updatedUsers);
                }}
              />
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Site Name
                  </label>
                  <input
                    type="text"
                    value={data.settings.siteName}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Currency
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Timezone
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="UTC">UTC</option>
                    <option value="EST">EST</option>
                    <option value="PST">PST</option>
                  </select>
                </div>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium">
                  Save Settings
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Contact Hero Form - Available from any tab */}
      {editingItem === 'contact-hero' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800">Edit Contact Hero Section</h3>
                <button
                  onClick={() => {
                    setEditingItem(null);
                    setFormData({});
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                  <input
                    type="text"
                    value={formData.title || ''}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle (optional)</label>
                  <input
                    type="text"
                    value={formData.subtitle || ''}
                    onChange={(e) => handleInputChange('subtitle', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={formData.description || ''}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    rows={3}
                    placeholder="Main description text"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Background Image URL</label>
                  <input
                    type="url"
                    value={formData.backgroundImage || ''}
                    onChange={(e) => handleInputChange('backgroundImage', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div className="flex justify-end space-x-4 pt-6">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingItem(null);
                      setFormData({});
                    }}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Contact Get in Touch Form - Available from any tab */}
      {editingItem === 'contact-get-in-touch' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800">Edit Get in Touch Section</h3>
                <button
                  onClick={() => {
                    setEditingItem(null);
                    setFormData({});
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Main Section */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Main Content</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Location Section */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Location</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.locationTitle || ''}
                        onChange={(e) => handleInputChange('locationTitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                      <input
                        type="text"
                        value={formData.locationIcon || ''}
                        onChange={(e) => handleInputChange('locationIcon', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="ri-map-pin-line"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                      <select
                        value={formData.locationColor || ''}
                        onChange={(e) => handleInputChange('locationColor', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      >
                        <option value="refex-blue">Refex Blue</option>
                        <option value="refex-green">Refex Green</option>
                        <option value="refex-orange">Refex Orange</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Address (HTML allowed)</label>
                      <textarea
                        value={formData.locationAddress || ''}
                        onChange={(e) => handleInputChange('locationAddress', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        placeholder="Refex Building, 67, Bazullah Road&lt;br /&gt;Parthasarathy Puram, T Nagar&lt;br /&gt;Chennai, 600017"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Phone Section */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Phone</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.phoneTitle || ''}
                        onChange={(e) => handleInputChange('phoneTitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <input
                        type="text"
                        value={formData.phoneNumber || ''}
                        onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                      <input
                        type="text"
                        value={formData.phoneIcon || ''}
                        onChange={(e) => handleInputChange('phoneIcon', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="ri-phone-line"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                      <select
                        value={formData.phoneColor || ''}
                        onChange={(e) => handleInputChange('phoneColor', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      >
                        <option value="refex-blue">Refex Blue</option>
                        <option value="refex-green">Refex Green</option>
                        <option value="refex-orange">Refex Orange</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Hours</label>
                      <input
                        type="text"
                        value={formData.phoneHours || ''}
                        onChange={(e) => handleInputChange('phoneHours', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Monday - Friday, 9:00 AM - 6:00 PM IST"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Email Section */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Email</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.emailTitle || ''}
                        onChange={(e) => handleInputChange('emailTitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <input
                        type="email"
                        value={formData.emailAddress || ''}
                        onChange={(e) => handleInputChange('emailAddress', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                      <input
                        type="text"
                        value={formData.emailIcon || ''}
                        onChange={(e) => handleInputChange('emailIcon', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="ri-mail-line"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                      <select
                        value={formData.emailColor || ''}
                        onChange={(e) => handleInputChange('emailColor', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      >
                        <option value="refex-blue">Refex Blue</option>
                        <option value="refex-green">Refex Green</option>
                        <option value="refex-orange">Refex Orange</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Response Time</label>
                      <input
                        type="text"
                        value={formData.emailResponseTime || ''}
                        onChange={(e) => handleInputChange('emailResponseTime', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="We'll respond within 24 hours"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Business Hours Section */}
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Business Hours</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.businessHoursTitle || ''}
                        onChange={(e) => handleInputChange('businessHoursTitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Monday - Friday</label>
                      <input
                        type="text"
                        value={formData.businessHoursMondayFriday || ''}
                        onChange={(e) => handleInputChange('businessHoursMondayFriday', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="9:00 AM - 6:00 PM"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Saturday</label>
                      <input
                        type="text"
                        value={formData.businessHoursSaturday || ''}
                        onChange={(e) => handleInputChange('businessHoursSaturday', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="10:00 AM - 4:00 PM"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Sunday</label>
                      <input
                        type="text"
                        value={formData.businessHoursSunday || ''}
                        onChange={(e) => handleInputChange('businessHoursSunday', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Closed"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 pt-6">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingItem(null);
                      setFormData({});
                    }}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-gray-800">
                  {modalType === 'add' ? 'Add New' : 'Edit'} {
                    activeTab === 'home-page'
                      ? activeHomeSection.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())
                      : activeTab === 'about-page'
                        ? activeAboutSection.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())
                        : 'Capabilities'
                  }
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Home Page Forms (scoped) */}
                {activeTab === 'home-page' && (
                  <>
                {/* Hero Slides Form */}
                {activeHomeSection === 'hero-slides' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                      <input
                        type="url"
                        value={formData.image || ''}
                        onChange={(e) => handleInputChange('image', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    {/* Description field intentionally removed as requested */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                      <input
                        type="number"
                        value={formData.order || ''}
                        onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="mr-2"
                      />
                      <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                    </div>
                  </>
                )}

                {/* Offerings Form */}
                {activeHomeSection === 'offerings' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Metric</label>
                        <input
                          type="text"
                          value={formData.metric || ''}
                          onChange={(e) => handleInputChange('metric', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                        <input
                          type="text"
                          value={formData.unit || ''}
                          onChange={(e) => handleInputChange('unit', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color Theme</label>
                      <select
                        value={formData.color || 'refex-blue'}
                        onChange={(e) => handleInputChange('color', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="refex-blue">Refex Blue (#2879b6)</option>
                        <option value="refex-green">Refex Green (#7dc244)</option>
                        <option value="refex-orange">Refex Orange (#ee6a31)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                      <input
                        type="number"
                        value={formData.order || ''}
                        onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="mr-2"
                      />
                      <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                    </div>
                  </>
                )}

                {/* Statistics Form */}
                {activeHomeSection === 'statistics' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Value</label>
                      <input
                        type="number"
                        value={formData.value || ''}
                        onChange={(e) => handleInputChange('value', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                      <input
                        type="url"
                        value={formData.image || ''}
                        onChange={(e) => handleInputChange('image', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color Theme</label>
                      <select
                        value={formData.color || 'refex-blue'}
                        onChange={(e) => handleInputChange('color', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="refex-blue">Refex Blue (#2879b6)</option>
                        <option value="refex-green">Refex Green (#7dc244)</option>
                        <option value="refex-orange">Refex Orange (#ee6a31)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                      <input
                        type="number"
                        value={formData.order || ''}
                        onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="mr-2"
                      />
                      <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                    </div>
                  </>
                )}

                {/* Regulatory Form */}
                {activeHomeSection === 'regulatory' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                      <input
                        type="url"
                        value={formData.image || ''}
                        onChange={(e) => handleInputChange('image', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Link URL (optional)</label>
                      <input
                        type="url"
                        value={formData.link || ''}
                        onChange={(e) => handleInputChange('link', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="https://regulator.example"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                      <input
                        type="color"
                        value={formData.color || '#2879b6'}
                        onChange={(e) => handleInputChange('color', e.target.value)}
                        className="w-full h-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                      <input
                        type="number"
                        value={formData.order || ''}
                        onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="mr-2"
                      />
                      <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                    </div>
                  </>
                )}
                  </>
                )}

                {/* About Page Forms */}
                {activeTab === 'about-page' && (
                  <>
                    {/* Vision & Mission Form */}
                    {activeAboutSection === 'vision-mission' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Vision Title</label>
                          <input
                            type="text"
                            value={formData.visionTitle || ''}
                            onChange={(e) => handleInputChange('visionTitle', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Vision Description</label>
                          <textarea
                            value={formData.visionDescription || ''}
                            onChange={(e) => handleInputChange('visionDescription', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Vision Image URL</label>
                          <input
                            type="url"
                            value={formData.visionImage || ''}
                            onChange={(e) => handleInputChange('visionImage', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Mission Title</label>
                          <input
                            type="text"
                            value={formData.missionTitle || ''}
                            onChange={(e) => handleInputChange('missionTitle', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Mission Image URL</label>
                          <input
                            type="url"
                            value={formData.missionImage || ''}
                            onChange={(e) => handleInputChange('missionImage', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Mission Points (JSON)</label>
                          <textarea
                            value={formData.missionPointsRaw ?? JSON.stringify(formData.missionPoints || [], null, 2)}
                            onChange={(e) => handleInputChange('missionPointsRaw', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-xs"
                            rows={6}
                          />
                        </div>
                      </>
                    )}
                    {/* Journey Image Form */}
                    {activeAboutSection === 'about-journey-image' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                          <input
                            type="url"
                            value={formData.image || ''}
                            onChange={(e) => handleInputChange('image', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                            <select
                              value={formData.color || 'refex-blue'}
                              onChange={(e) => handleInputChange('color', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            >
                              <option value="refex-blue">refex-blue</option>
                              <option value="refex-green">refex-green</option>
                              <option value="refex-orange">refex-orange</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                            <input
                              type="number"
                              value={formData.order || 1}
                              onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive ?? true}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">Active</label>
                        </div>
                      </>
                    )}
                    {/* About Hero Form */}
                    {activeAboutSection === 'about-hero' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                          <input
                            type="text"
                            value={formData.title || ''}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle</label>
                          <input
                            type="text"
                            value={formData.subtitle || ''}
                            onChange={(e) => handleInputChange('subtitle', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={formData.description || ''}
                            onChange={(e) => handleInputChange('description', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Background Image URL</label>
                          <input
                            type="url"
                            value={formData.backgroundImage || ''}
                            onChange={(e) => handleInputChange('backgroundImage', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive ?? true}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="mr-2"
                          />
                          <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                        </div>
                      </>
                    )}
                    {/* About Sections Form */}
                    {activeAboutSection === 'about-sections' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                          <input
                            type="text"
                            value={formData.title || ''}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Content</label>
                          <textarea
                            value={formData.content || ''}
                            onChange={(e) => handleInputChange('content', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                          <input
                            type="text"
                            value={formData.icon || ''}
                            onChange={(e) => handleInputChange('icon', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="ri-heart-line"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                          <input
                            type="color"
                            value={formData.color || '#2879b6'}
                            onChange={(e) => handleInputChange('color', e.target.value)}
                            className="w-full h-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                          <input
                            type="number"
                            value={formData.order || ''}
                            onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive || false}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                            Active
                          </label>
                        </div>
                      </>
                    )}

                    {/* Leadership Form (Advisory Board, Technical Leadership Team and Management Team use same form) */}
                    {(activeAboutSection === 'leadership' || activeAboutSection === 'advisory-board' || activeAboutSection === 'technical-leadership' || activeAboutSection === 'management-team') && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                          <input
                            type="text"
                            value={formData.name || ''}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Position</label>
                          <input
                            type="text"
                            value={formData.position || ''}
                            onChange={(e) => handleInputChange('position', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={formData.description || ''}
                            onChange={(e) => handleInputChange('description', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                            required
                          />
                        </div>
                        {(activeAboutSection === 'leadership' || activeAboutSection === 'technical-leadership') && (
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                            <select
                              value={formData.category || 'Technical Leadership Team'}
                              onChange={(e) => handleInputChange('category', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            >
                              <option value="Advisory Board">Advisory Board</option>
                              <option value="Technical Leadership Team">Technical Leadership Team</option>
                              <option value="Management Team">Management Team</option>
                            </select>
                          </div>
                        )}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Achievements</label>
                          <div className="space-y-2">
                            {(formData.achievements || []).map((achievement: string, index: number) => (
                              <div key={index} className="flex items-center space-x-2">
                                <input
                                  type="text"
                                  value={achievement}
                                  onChange={(e) => {
                                    const newAchievements = [...(formData.achievements || [])];
                                    newAchievements[index] = e.target.value;
                                    handleInputChange('achievements', newAchievements);
                                  }}
                                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                  placeholder={`Achievement ${index + 1}`}
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newAchievements = (formData.achievements || []).filter((_: any, i: number) => i !== index);
                                    handleInputChange('achievements', newAchievements);
                                  }}
                                  className="px-3 py-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors"
                                >
                                  <i className="ri-delete-bin-line"></i>
                                </button>
                              </div>
                            ))}
                            <button
                              type="button"
                              onClick={() => {
                                const newAchievements = [...(formData.achievements || []), ''];
                                handleInputChange('achievements', newAchievements);
                              }}
                              className="w-full px-4 py-2 border-2 border-dashed border-gray-300 text-gray-600 hover:border-blue-500 hover:text-blue-600 rounded-lg transition-colors flex items-center justify-center"
                            >
                              <i className="ri-add-line mr-2"></i>
                              Add Achievement
                            </button>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Experience</label>
                            <input
                              type="text"
                              value={formData.experience || ''}
                              onChange={(e) => handleInputChange('experience', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Education</label>
                            <input
                              type="text"
                              value={formData.education || ''}
                              onChange={(e) => handleInputChange('education', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Color Theme</label>
                            <select
                              value={formData.color || 'refex-blue'}
                              onChange={(e) => handleInputChange('color', e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            >
                              <option value="refex-blue">Refex Blue (#2879b6)</option>
                              <option value="refex-green">Refex Green (#7dc244)</option>
                              <option value="refex-orange">Refex Orange (#ee6a31)</option>
                            </select>
                            <div className="mt-2 flex space-x-2">
                              <div className="flex items-center space-x-1">
                                <div className="w-4 h-4 rounded-full bg-[#2879b6]"></div>
                                <span className="text-xs text-gray-600">Blue</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <div className="w-4 h-4 rounded-full bg-[#7dc244]"></div>
                                <span className="text-xs text-gray-600">Green</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <div className="w-4 h-4 rounded-full bg-[#ee6a31]"></div>
                                <span className="text-xs text-gray-600">Orange</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Profile Image</label>
                          
                          {/* Image Preview */}
                          {(imagePreview || formData.image) && (
                            <div className="mb-4">
                              <img
                                src={imagePreview || formData.image}
                                alt="Preview"
                                className="w-24 h-24 object-cover rounded-full border-2 border-gray-300"
                              />
                            </div>
                          )}
                          
                          {/* Upload Option */}
                          <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Upload Image</label>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleImageUpload}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            <p className="text-xs text-gray-500 mt-1">Max size: 1MB. Supported formats: JPG, PNG, GIF. Use external URLs for larger images.</p>
                          </div>
                          
                          {/* URL Option */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Or Enter Image URL</label>
                            <input
                              type="url"
                              value={formData.image || ''}
                              onChange={(e) => {
                                handleInputChange('image', e.target.value);
                                setImagePreview(null);
                              }}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              placeholder="https://example.com/image.jpg"
                            />
                          </div>
                        </div>
                       
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                          <input
                            type="number"
                            value={formData.order || ''}
                            onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive || false}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                            Active
                          </label>
                        </div>
                      </>
                    )}

                    {/* Values Form */}
                    {activeAboutSection === 'values' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                          <input
                            type="text"
                            value={formData.title || ''}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={formData.description || ''}
                            onChange={(e) => handleInputChange('description', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                          <input
                            type="text"
                            value={formData.icon || ''}
                            onChange={(e) => handleInputChange('icon', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="ri-heart-line"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                          <input
                            type="color"
                            value={formData.color || '#2879b6'}
                            onChange={(e) => handleInputChange('color', e.target.value)}
                            className="w-full h-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                          <input
                            type="number"
                            value={formData.order || ''}
                            onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive || false}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                            Active
                          </label>
                        </div>
                      </>
                    )}

                    {/* Journey Form */}
                    {activeAboutSection === 'journey' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                          <input
                            type="text"
                            value={formData.title || ''}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={formData.description || ''}
                            onChange={(e) => handleInputChange('description', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={4}
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
                          <input
                            type="text"
                            value={formData.year || ''}
                            onChange={(e) => handleInputChange('year', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="2022-2023"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                          <input
                            type="url"
                            value={formData.image || ''}
                            onChange={(e) => handleInputChange('image', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                          <input
                            type="color"
                            value={formData.color || '#2879b6'}
                            onChange={(e) => handleInputChange('color', e.target.value)}
                            className="w-full h-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                          <input
                            type="number"
                            value={formData.order || ''}
                            onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive || false}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                            Active
                          </label>
                        </div>
                      </>
                    )}
                  </>
                )}

                {/* Capabilities Form */}
                {activeTab === 'capabilities' && (
                  <>
                    {/* Capabilities Hero Form */}
                    {editingItem === 'capabilities-hero' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                          <input
                            type="text"
                            value={formData.title || ''}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle (optional)</label>
                          <input
                            type="text"
                            value={formData.subtitle || ''}
                            onChange={(e) => handleInputChange('subtitle', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                          <textarea
                            value={formData.description || ''}
                            onChange={(e) => handleInputChange('description', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={3}
                            placeholder="Main description text"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Sub Description (optional)</label>
                          <textarea
                            value={formData.subDescription || ''}
                            onChange={(e) => handleInputChange('subDescription', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows={2}
                            placeholder="Additional description text"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Background Image URL</label>
                          <input
                            type="url"
                            value={formData.backgroundImage || ''}
                            onChange={(e) => handleInputChange('backgroundImage', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                      </>
                    )}

                {/* Contact Hero Form */}
                {editingItem === 'contact-hero' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle (optional)</label>
                      <input
                        type="text"
                        value={formData.subtitle || ''}
                        onChange={(e) => handleInputChange('subtitle', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        placeholder="Main description text"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Background Image URL</label>
                      <input
                        type="url"
                        value={formData.backgroundImage || ''}
                        onChange={(e) => handleInputChange('backgroundImage', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                  </>
                )}

                {/* Contact User Form */}
                {editingItem === 'contact-user' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                      <input
                        type="text"
                        value={formData.name || ''}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                      <input
                        type="email"
                        value={formData.email || ''}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                      <input
                        type="tel"
                        value={formData.phone || ''}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
                      <input
                        type="text"
                        value={formData.department || ''}
                        onChange={(e) => handleInputChange('department', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Position</label>
                      <input
                        type="text"
                        value={formData.position || ''}
                        onChange={(e) => handleInputChange('position', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Avatar URL</label>
                      <input
                        type="url"
                        value={formData.avatar || ''}
                        onChange={(e) => handleInputChange('avatar', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="https://example.com/avatar.jpg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                      <input
                        type="number"
                        value={formData.order || 0}
                        onChange={(e) => handleInputChange('order', parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        min="0"
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                        Active
                      </label>
                    </div>
                  </>
                )}

                {/* Home Global Impact Form */}
                {editingItem === 'home-global-impact' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Section Title</label>
                      <input
                        type="text"
                        value={formData.title || ''}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                      <textarea
                        value={formData.description || ''}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        placeholder="Section description text"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={formData.isActive || false}
                        onChange={(e) => handleInputChange('isActive', e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                        Active
                      </label>
                    </div>
                  </>
                )}
                    {editingItem === 'capabilities-research' && (
                      <>
                        {/* Main Section */}
                        <div className="border-b border-gray-200 pb-6 mb-6">
                          <h3 className="text-lg font-semibold text-gray-800 mb-4">Main Section</h3>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                              <input
                                type="text"
                                value={formData.title || ''}
                                onChange={(e) => handleInputChange('title', e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                              <textarea
                                value={formData.description || ''}
                                onChange={(e) => handleInputChange('description', e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows={4}
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                              <input
                                type="url"
                                value={formData.image || ''}
                                onChange={(e) => handleInputChange('image', e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                            </div>
                          </div>
                        </div>

                        {/* API Card */}
                        <div className="border-b border-gray-200 pb-6 mb-6">
                          <h3 className="text-lg font-semibold text-gray-800 mb-4">API R&D Card</h3>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Card Title</label>
                              <input
                                type="text"
                                value={formData.apiCard?.title || ''}
                                onChange={(e) => {
                                  console.log('API Card Title Change:', e.target.value);
                                  handleInputChange('apiCard', { ...formData.apiCard, title: e.target.value });
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                              <p className="text-xs text-gray-500 mt-1">Current value: "{formData.apiCard?.title || 'empty'}"</p>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle</label>
                              <input
                                type="text"
                                value={formData.apiCard?.subtitle || ''}
                                onChange={(e) => {
                                  console.log('API Card Subtitle Change:', e.target.value);
                                  handleInputChange('apiCard', { ...formData.apiCard, subtitle: e.target.value });
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                              <p className="text-xs text-gray-500 mt-1">Current value: "{formData.apiCard?.subtitle || 'empty'}"</p>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Icon (Remix Icon class)</label>
                              <input
                                type="text"
                                value={formData.apiCard?.icon || ''}
                                onChange={(e) => handleInputChange('apiCard', { ...formData.apiCard, icon: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="e.g., ri-flask-line"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Color (Hex)</label>
                              <input
                                type="text"
                                value={formData.apiCard?.color || ''}
                                onChange={(e) => handleInputChange('apiCard', { ...formData.apiCard, color: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="#2879b6"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Points</label>
                              <div className="space-y-3">
                                {(formData.apiCard?.points || []).map((point: any, index: number) => (
                                  <div key={index} className="flex gap-2 items-start">
                                    <div className="flex-1">
                                      <input
                                        type="text"
                                        value={point.title || ''}
                                        onChange={(e) => {
                                          const newPoints = [...(formData.apiCard?.points || [])];
                                          newPoints[index] = { ...newPoints[index], title: e.target.value };
                                          handleInputChange('apiCard', { ...formData.apiCard, points: newPoints });
                                        }}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                        placeholder="Point title"
                                      />
                                    </div>
                                    <div className="flex-1">
                                      <input
                                        type="text"
                                        value={point.description || ''}
                                        onChange={(e) => {
                                          const newPoints = [...(formData.apiCard?.points || [])];
                                          newPoints[index] = { ...newPoints[index], description: e.target.value };
                                          handleInputChange('apiCard', { ...formData.apiCard, points: newPoints });
                                        }}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                        placeholder="Point description"
                                      />
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const newPoints = (formData.apiCard?.points || []).filter((_: any, i: number) => i !== index);
                                        handleInputChange('apiCard', { ...formData.apiCard, points: newPoints });
                                      }}
                                      className="px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm"
                                    >
                                      <i className="ri-delete-bin-line"></i>
                                    </button>
                                  </div>
                                ))}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newPoints = [...(formData.apiCard?.points || []), { title: '', description: '' }];
                                    handleInputChange('apiCard', { ...formData.apiCard, points: newPoints });
                                  }}
                                  className="w-full px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium"
                                >
                                  <i className="ri-add-line mr-2"></i>
                                  Add Point
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* FDF Card */}
                        <div className="border-b border-gray-200 pb-6 mb-6">
                          <h3 className="text-lg font-semibold text-gray-800 mb-4">FDF R&D Card</h3>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Card Title</label>
                              <input
                                type="text"
                                value={formData.fdfCard?.title || ''}
                                onChange={(e) => handleInputChange('fdfCard', { ...formData.fdfCard, title: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle</label>
                              <input
                                type="text"
                                value={formData.fdfCard?.subtitle || ''}
                                onChange={(e) => handleInputChange('fdfCard', { ...formData.fdfCard, subtitle: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Icon (Remix Icon class)</label>
                              <input
                                type="text"
                                value={formData.fdfCard?.icon || ''}
                                onChange={(e) => handleInputChange('fdfCard', { ...formData.fdfCard, icon: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="e.g., ri-capsule-line"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Color (Hex)</label>
                              <input
                                type="text"
                                value={formData.fdfCard?.color || ''}
                                onChange={(e) => handleInputChange('fdfCard', { ...formData.fdfCard, color: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="#7dc244"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Points</label>
                              <div className="space-y-3">
                                {(formData.fdfCard?.points || []).map((point: any, index: number) => (
                                  <div key={index} className="flex gap-2 items-start">
                                    <div className="flex-1">
                                      <input
                                        type="text"
                                        value={point.title || ''}
                                        onChange={(e) => {
                                          const newPoints = [...(formData.fdfCard?.points || [])];
                                          newPoints[index] = { ...newPoints[index], title: e.target.value };
                                          handleInputChange('fdfCard', { ...formData.fdfCard, points: newPoints });
                                        }}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                        placeholder="Point title"
                                      />
                                    </div>
                                    <div className="flex-1">
                                      <input
                                        type="text"
                                        value={point.description || ''}
                                        onChange={(e) => {
                                          const newPoints = [...(formData.fdfCard?.points || [])];
                                          newPoints[index] = { ...newPoints[index], description: e.target.value };
                                          handleInputChange('fdfCard', { ...formData.fdfCard, points: newPoints });
                                        }}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                        placeholder="Point description"
                                      />
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const newPoints = (formData.fdfCard?.points || []).filter((_: any, i: number) => i !== index);
                                        handleInputChange('fdfCard', { ...formData.fdfCard, points: newPoints });
                                      }}
                                      className="px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm"
                                    >
                                      <i className="ri-delete-bin-line"></i>
                                    </button>
                                  </div>
                                ))}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newPoints = [...(formData.fdfCard?.points || []), { title: '', description: '' }];
                                    handleInputChange('fdfCard', { ...formData.fdfCard, points: newPoints });
                                  }}
                                  className="w-full px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium"
                                >
                                  <i className="ri-add-line mr-2"></i>
                                  Add Point
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Promise Section */}
                        <div className="pb-6">
                          <h3 className="text-lg font-semibold text-gray-800 mb-4">R&D Promise Section</h3>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Promise Title</label>
                              <input
                                type="text"
                                value={formData.promise?.title || ''}
                                onChange={(e) => handleInputChange('promise', { ...formData.promise, title: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Promise Description</label>
                              <textarea
                                value={formData.promise?.description || ''}
                                onChange={(e) => handleInputChange('promise', { ...formData.promise, description: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows={3}
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Icon (Remix Icon class)</label>
                              <input
                                type="text"
                                value={formData.promise?.icon || ''}
                                onChange={(e) => handleInputChange('promise', { ...formData.promise, icon: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                placeholder="e.g., ri-lightbulb-line"
                                required
                              />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="isActive"
                            checked={formData.isActive ?? true}
                            onChange={(e) => handleInputChange('isActive', e.target.checked)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">Active</label>
                        </div>
                      </>
                    )}

                    {/* Generic Form Fields - Only show for facilities */}
                    {editingItem && !['capabilities-hero', 'capabilities-research'].includes(editingItem) && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                          <input
                            type="text"
                            value={formData.name || ''}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
                        <select
                          value={formData.type || 'API Manufacturing'}
                          onChange={(e) => handleInputChange('type', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option>API Manufacturing</option>
                          <option>Oncology & Specialty Intermediates</option>
                          <option>Formulations & Complex Generics</option>
                          <option>Packaging & Customization</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Established</label>
                        <input
                          type="text"
                          value={formData.established || ''}
                          onChange={(e) => handleInputChange('established', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                        <input
                          type="text"
                          value={formData.location || ''}
                          onChange={(e) => handleInputChange('location', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Capacity</label>
                        <input
                          type="text"
                          value={formData.capacity || ''}
                          onChange={(e) => handleInputChange('capacity', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                      <input
                        type="url"
                        value={formData.image || ''}
                        onChange={(e) => handleInputChange('image', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Capabilities</label>
                      <div className="space-y-2">
                        {(Array.isArray(formData.capabilities) && formData.capabilities.length > 0 ? formData.capabilities : ['']).map((cap: string, idx: number) => (
                          <div key={idx} className="flex items-center gap-2">
                            <input
                              type="text"
                              value={cap}
                              onChange={(e) => setFormData((prev: any) => {
                                const next = Array.isArray(prev.capabilities) ? [...prev.capabilities] : [];
                                next[idx] = e.target.value;
                                return { ...prev, capabilities: next };
                              })}
                              placeholder="e.g., High-vacuum distillation"
                              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            <button
                              type="button"
                              onClick={() => setFormData((prev: any) => {
                                const next = (Array.isArray(prev.capabilities) ? [...prev.capabilities] : []);
                                next.splice(idx, 1);
                                return { ...prev, capabilities: next.length ? next : [''] };
                              })}
                              className="px-2 py-2 bg-red-50 text-red-600 rounded hover:bg-red-100"
                              title="Remove"
                            >
                              <i className="ri-delete-bin-6-line"></i>
                            </button>
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() => setFormData((prev: any) => ({ ...prev, capabilities: [...(prev.capabilities || []), ''] }))}
                          className="mt-1 inline-flex items-center px-3 py-1.5 bg-blue-50 text-blue-700 rounded hover:bg-blue-100 text-sm"
                        >
                          <i className="ri-add-line mr-1"></i>
                          Add Capability
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Approval Logos (URLs)</label>
                      <div className="space-y-2">
                        {(Array.isArray(formData.approvals) && formData.approvals.length > 0 ? formData.approvals : ['']).map((url: string, idx: number) => (
                          <div key={idx} className="flex items-center gap-2">
                            <input
                              type="url"
                              value={url}
                              onChange={(e) => setFormData((prev: any) => {
                                const next = Array.isArray(prev.approvals) ? [...prev.approvals] : [];
                                next[idx] = e.target.value;
                                return { ...prev, approvals: next };
                              })}
                              placeholder="https://example.com/logo.png"
                              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            <button
                              type="button"
                              onClick={() => setFormData((prev: any) => {
                                const next = (Array.isArray(prev.approvals) ? [...prev.approvals] : []);
                                next.splice(idx, 1);
                                return { ...prev, approvals: next.length ? next : [''] };
                              })}
                              className="px-2 py-2 bg-red-50 text-red-600 rounded hover:bg-red-100"
                              title="Remove"
                            >
                              <i className="ri-delete-bin-6-line"></i>
                            </button>
                            {url && (
                              <img src={url} alt="Logo" className="w-10 h-8 object-contain rounded border" />
                            )}
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() => setFormData((prev: any) => ({ ...prev, approvals: [...(prev.approvals || []), ''] }))}
                          className="mt-1 inline-flex items-center px-3 py-1.5 bg-blue-50 text-blue-700 rounded hover:bg-blue-100 text-sm"
                        >
                          <i className="ri-add-line mr-1"></i>
                          Add Logo
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                        <select
                          value={formData.color || 'refex-blue'}
                          onChange={(e) => handleInputChange('color', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option value="refex-blue">refex-blue</option>
                          <option value="refex-green">refex-green</option>
                          <option value="refex-orange">refex-orange</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Order</label>
                        <input
                          type="number"
                          value={formData.order || 1}
                          onChange={(e) => handleInputChange('order', parseInt(e.target.value))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div className="flex items-center mt-7">
                        <input
                          type="checkbox"
                          id="isActive"
                          checked={formData.isActive ?? true}
                          onChange={(e) => handleInputChange('isActive', e.target.checked)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">Active</label>
                      </div>
                    </div>
                  </>
                )}
                  </>
                )}

                <div className="flex justify-end space-x-4 pt-6">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setImagePreview(null);
                    }}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    {modalType === 'add' ? 'Add' : 'Update'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
